import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.locks.Condition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chromium.AddHasNetworkConditions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EightAddToCartMultiple {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
		
		driver.manage().window().maximize();
		
		//Implicit Wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(200));
		
	
		String[] itemNeeded= {"Cucumber","Brocolli","Beetroot"};
		int j=0;
		
		List<WebElement> products=driver.findElements(By.cssSelector("h4.product-name"));
		for(int i=0; i<products.size();i++)
		{
			String[] names=products.get(i).getText().split("-");
			String formattedName=names[0].trim();
			
			List itemNeededList= Arrays.asList(itemNeeded);
			if(itemNeededList.contains(formattedName))
			{
				j++;
				driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click();
				
				if(j==itemNeeded.length)
				{
					break;
					
				}
			}
			
			driver.findElement(By.cssSelector("img[alt='Cart'")).click();
			driver.findElement(By.xpath("//button[text()='PROCEED TO CHECKOUT']")).click();
			driver.findElement(By.cssSelector("input.promoCode")).sendKeys("rahulshettyacademy");
			driver.findElement(By.cssSelector("button.promoBtn")).click();
			
			//Explicit Wait
			WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(2000));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("span.promoInfo")));
			
			System.out.println(driver.findElement(By.cssSelector("span.promoInfo")).getText());
			driver.findElement(By.xpath("//button[text()='Place Order']")).click();
			
		}

	}

}
