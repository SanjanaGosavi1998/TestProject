import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class EighteenBrokenLinks {

	public static void main(String[] args) throws MalformedURLException, IOException, URISyntaxException {
	
		WebDriver driver =new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
	
		List<WebElement> links = driver.findElements(By.cssSelector("li[class='gf-li'] a"));
		for(WebElement link: links)
		{
			String url= link.getAttribute("href");
			HttpURLConnection conn=(HttpURLConnection) new URI(url).toURL().openConnection();
			conn.setRequestMethod("HEAD");
			conn.connect();
			int respcode= conn.getResponseCode();
			System.out.println(respcode);
			if(respcode>400) {
				System.out.println("The Link with Text"+ link.getText()+"is broken with code"+ respcode);
				Assert.assertTrue(false);
			}
		}
		

	}

}
