import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ElevenWindowHandles {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/loginpagePractise/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2000));

		driver.findElement(By.cssSelector(".blinkingText")).click();

		Set<String> windows = driver.getWindowHandles(); // [ParentID,ChildID]
		Iterator<String> it = windows.iterator();
		String ParentId = it.next();
		String ChildID = it.next();
		driver.switchTo().window(ChildID);

		System.out.println(driver.findElement(By.cssSelector(".im-para.red")).getText());

		String[] mail = driver.findElement(By.cssSelector(".im-para.red")).getText().split("at");
		// 0th=Please email us
		// 1st= mentor@rahulshettyacademy.com with below template to receive response
		String[] mail1 = mail[1].split("with");
		String Final = mail1[0].trim();

		driver.switchTo().window(ParentId);
		driver.findElement(By.id("username")).sendKeys(Final);

	}

}
