import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FifteenScroll {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();

		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		driver.manage().window().maximize();
		
		//Scroll on page
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,600)");
		
		Thread.sleep(3000);
		
		//For table scroll
		js.executeScript("document.querySelector('.tableFixHead').scrollTop=5000");

		//Sum the values which present in table
		List<WebElement> values=driver.findElements(By.cssSelector(".tableFixHead td:nth-child(4)"));
		int sum=0;
		for(int i=0; i<values.size();i++)
		{
			sum= sum+ Integer.parseInt(values.get(i).getText());
		}
		System.out.println(sum);
		
		
		
		//Check the values get and actual is same or not
		
		//driver.findElement(By.cssSelector(".totalAmount")).getText();
		//driver.findElement(By.cssSelector(".totalAmount")).getText().split(":")[1].trim(); //In String format 
		//Need to convert string to Integer
		int total= Integer.parseInt(driver.findElement(By.cssSelector(".totalAmount")).getText().split(":")[1].trim());
		//Assert.assertEquals(sum, total);
	}
	


}
