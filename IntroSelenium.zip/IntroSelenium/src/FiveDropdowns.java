import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FiveDropdowns {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(200));
		
		//Static Dropdown

		WebElement StaticDropdown= driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency"));
		Select dropdown= new Select(StaticDropdown);
		
		System.out.println(dropdown.getFirstSelectedOption().getText());
		dropdown.selectByValue("AED");
		System.out.println(dropdown.getFirstSelectedOption().getText());
		dropdown.selectByVisibleText("USD");
		System.out.println(dropdown.getFirstSelectedOption().getText());
		dropdown.selectByIndex(0);
		System.out.println(dropdown.getFirstSelectedOption().getText());
		
		Thread.sleep(2000);
		
		//Another Dropdown
		driver.findElement(By.id("divpaxinfo")).click();
		
		System.out.println(driver.findElement(By.id("divpaxinfo")).getText());
		
		for(int i=1; i<=5; i++)
		{
			driver.findElement(By.id("hrefIncAdt")).click();
		}
		driver.findElement(By.className("buttonN")).click();
		
		System.out.println(driver.findElement(By.id("divpaxinfo")).getText());
		
		Thread.sleep(2000);
		
		//Dynamic Dropdown
		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
		driver.findElement(By.xpath("//a[@value='BOM']")).click();
		driver.findElement(By.xpath("//div[@id='glsctl00_mainContent_ddl_destinationStation1_CTNR'] //a[@value='IXL']")).click();
		//or
		//a[@value='IXL'][2]
		
		Thread.sleep(2000);
		
		//Calender
		driver.findElement(By.className("ui-state-active")).click();
		
		Thread.sleep(2000);
		
		//Chechbox
		System.out.println(driver.findElement(By.id("ctl00_mainContent_chk_friendsandfamily")).isSelected()); //False
		driver.findElement(By.id("ctl00_mainContent_chk_friendsandfamily")).click();
		System.out.println(driver.findElement(By.id("ctl00_mainContent_chk_friendsandfamily")).isSelected()); //True
		System.out.println(driver.findElements(By.xpath("//input[@type='checkbox']")).size());
		//Assert.assertTrue(driver.findElement(By.id("ctl00_mainContent_chk_friendsandfamily")).isSelected();
		
		Thread.sleep(2000);
		
		//AutoSuggestive Dropdown
		driver.findElement(By.id("autosuggest")).sendKeys("ind");
		List<WebElement> options= driver.findElements(By.cssSelector("li[class='ui-menu-item'] a"));
		
		for(WebElement Final:options)
		{
			if(Final.getText().equalsIgnoreCase("india"))
			{
				Final.click();
				break;
			}
		}
		
		Thread.sleep(2000);
				
		//Round trip handle
		System.out.println(driver.findElement(By.id("Div1")).getDomAttribute("style"));
		driver.findElement(By.id("ctl00_mainContent_rbtnl_Trip_1")).click();
		System.out.println(driver.findElement(By.id("Div1")).getDomAttribute("style"));
		if(driver.findElement(By.id("Div1")).getDomAttribute("style").contains("1"))
		{
			System.out.println("Its Enabled");
			//Assert.assertTrue(true);
		}
		else{
			System.out.println("Its Disabled");
			//Assert.assertTrue(False);
		}
		
		Thread.sleep(2000);
		
		driver.findElement(By.id("ctl00_mainContent_btn_FindFlights")).click();
		driver.quit();
	}
	
	

}
