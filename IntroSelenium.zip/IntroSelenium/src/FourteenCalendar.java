import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FourteenCalendar {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
		driver.manage().window().maximize();
		
		
		String Month="6";
		String date= "15";
		String year= "2027";
		
		String[] expectedList= {Month, date, year};
		
		
		driver.findElement(By.className("react-date-picker__inputGroup")).click();
		driver.findElement(By.className("react-calendar__navigation__label")).click();
		driver.findElement(By.className("react-calendar__navigation__label")).click();
		
		driver.findElement(By.xpath("//button[text()='"+year+"']")).click();
		
		driver.findElements(By.cssSelector(".react-calendar__year-view__months__month")).get(Integer.parseInt(Month)-1).click();
		driver.findElement(By.xpath("//abbr[text()='"+date+"']")).click();
		
		System.out.println(driver.findElement(By.cssSelector(".react-date-picker__inputGroup")).getText());

		List<WebElement> actualList=driver.findElements(By.className(".react-date-picker__inputGroup__input"));

		for(int i=0;i<actualList.size();i++)
		{
			System.out.println(actualList.get(i).getAttribute("value"));
		//Assert.assertEquals(actualList.get(i).getAttribute("value"), expectedList[i]);

		}
	
	}
}
