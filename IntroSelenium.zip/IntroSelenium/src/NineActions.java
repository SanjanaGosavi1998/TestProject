import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class NineActions {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/tool-tips");
		
		//MouseHover
		Actions mouseHover=new Actions(driver);
		mouseHover.moveToElement(driver.findElement(By.id("toolTipButton"))).build().perform();
		//or
		WebElement move=driver.findElement(By.id("toolTipButton"));
		mouseHover.moveToElement(move).build().perform();
		
		
		
		//Send Text in capital letter
		mouseHover.moveToElement(driver.findElement(By.id("toolTipTextField"))).click().keyDown(Keys.SHIFT).sendKeys("sanjana").build().perform();
		//or
		WebElement text=driver.findElement(By.id("toolTipTextField"));
		mouseHover.moveToElement(text).click().keyDown(Keys.SHIFT).sendKeys("sanjana").build().perform();
		
		
		
		//Select text by using double click
		mouseHover.moveToElement(driver.findElement(By.id("toolTipTextField"))).click().keyDown(Keys.SHIFT).sendKeys("sanjana").doubleClick().build().perform();
		
		
		//Right click
		mouseHover.moveToElement(driver.findElement(By.id("toolTipButton"))).contextClick().build().perform();

		
		//Drag and Drop
		driver.get("https://demoqa.com/droppable");
		//Actions class
		WebElement source=driver.findElement(By.id("draggable"));
		WebElement target=driver.findElement(By.id("droppable"));
		mouseHover.dragAndDrop(source, target).build().perform();
		
	}

}
