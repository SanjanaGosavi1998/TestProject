import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class NineteenStream {

	public static void main(String[] args) {
		
		//Count the number of names starts with "A" in list
		//By java
		ArrayList<String> names=new ArrayList<String>();
		names.add("Abhijeet");
		names.add("Don");
		names.add("Alekhya");
		names.add("Adam");
		names.add("Rama");
		int count=0;
		for(int i=0; i<names.size();i++)
		{
			String actual=names.get(i);
			if(actual.startsWith("A"))
			{
				count++;
			}
		}

		System.out.println(count);
		
		//By Stream
		long c=names.stream().filter(s->s.startsWith("A")).count();
		System.out.println(c);
		
		//or
		long d=Stream.of("Abhijeet","Don","Alekhya","Adam","Rama").filter(s->
		{
			s.startsWith("D");
			return true;
		}).count();
		System.out.println(d);


		//Print the names which size is larger then 4 in arraylist
		names.stream().filter(s->s.length()>4).forEach(s->System.out.println(s));
		//If u want only first then
		names.stream().filter(s->s.length()>4).limit(1).forEach(s->System.out.println(s));
		
		//Print names which have last letter "a" and do Uppercase
		names.stream().filter(s->s.endsWith("a")).map(s->s.toUpperCase()).forEach(s->System.out.println(s));
		
		//Print names which have first letter as "A" with uppercase and do sorted
		List<String> name1=Arrays.asList("Abhijeet","Don","Alekhya","Adam","Rama");
		name1.stream().filter(s->s.startsWith("A")).map(s->s.toUpperCase()).sorted().forEach(s->System.out.println(s));
		
		//Merging two different Lists
		Stream<String> newstream= Stream.concat(names.stream(), name1.stream());
		newstream.sorted().forEach(s->System.out.println(s));
		
		//Adam is present or not in Arraylist
		//boolean flag=newstream.anyMatch(s->s.equalsIgnoreCase("Adam"));
		//System.out.println(flag);
		//Assert.assertTrue(flag);
		
		//List->newList->Print but in end i want to convert that newlist to list
		List<String> ls=Stream.of("Abhijeet","Don","Alekhya","Adam","Rama").filter(s->s.endsWith("a")).map(s->s.toUpperCase()).collect(Collectors.toList());
		System.out.println(ls.get(0));
		
		//Unique number from array
		List<Integer> values= Arrays.asList(3,4,2,3,7,9,4,6,3,8,9,7,5);
		values.stream().distinct().forEach(s->System.out.println(s));
		
		//Sorted->List->3rd result
		List<Integer> li=values.stream().distinct().sorted().collect(Collectors.toList());
		System.out.println(li);
		System.out.println(li.get(3));
	}

}
