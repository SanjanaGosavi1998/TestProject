import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class OneLocator {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/locatorspractice/");
		driver.manage().window().maximize();
		driver.findElement(By.id("inputUsername")).sendKeys("Sanja"); //ID
		driver.findElement(By.name("inputPassword")).sendKeys("abc123"); //name
		driver.findElement(By.className("signInBtn")).click(); //classname
		Thread.sleep(2000);
		
		System.out.println(driver.findElement(By.tagName("p")).getText()); //tagname
		
		driver.findElement(By.linkText("Forgot your password?")).click(); //LinkText
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@placeholder='Name']")).sendKeys("Sanjana"); //Xpath
		driver.findElement(By.cssSelector("input[placeholder='Email']")).sendKeys("sanja@gmail.com"); //Cssselector
		driver.findElement(By.xpath("//input[@placeholder='Phone Number']")).sendKeys("9864345363"); //Xpath
		driver.findElement(By.cssSelector(".reset-pwd-btn")).click(); //.classname by css
		
		System.out.println(driver.findElement(By.xpath("//div/form/p")).getText()); //Parent-child xpath
		
		driver.findElement(By.xpath("//button[text()='Go to Login']")).click(); //tagname[text()='gotologin'] by xpath
		Thread.sleep(2000);
		
		driver.findElement(By.cssSelector("#inputUsername")).sendKeys("Rahul"); //#id by css 
		driver.findElement(By.cssSelector("input[placeholder*='Pass']")).sendKeys("rahulshettyacademy"); //css regular expression
		driver.findElement(By.cssSelector("input#chkboxTwo")).click(); //tagname#id by css
		driver.findElement(By.xpath("//button[contains(@class,'submit')]")).click(); //xpath regular expression
		Thread.sleep(2000);
		
		System.out.println(driver.findElement(By.xpath("//div[@class='login-container']")).getText());
		driver.findElement(By.xpath("//button[text()='Log Out']")).click();
		driver.quit();
		

	}

}
