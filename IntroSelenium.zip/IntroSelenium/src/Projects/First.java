package Projects;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;

public class First {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2000));
		
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();

		
		//Actions a=new Actions(driver);
		//WebElement username=
		driver.findElement(By.xpath("//div/button[text()=' Add ']")).click();
		//a.moveToElement(username).click();
		
		driver.findElement(By.xpath("//label[text()='User Role']/ancestor::div[contains(@class,'oxd-input-group')]//div[contains(@class,'oxd-select-text-input')]")).click();
		driver.findElement(By.xpath("//span[normalize-space()='ESS']")).click();

//		WebElement text= driver.findElement(By.cssSelector("input[placeholder='Type for hints...']"));
//		text.sendKeys("manda");
//		Select dropdown=new Select(text);
//		dropdown.selectByVisibleText("manda AI_Orchestrator user");
//		System.out.println(dropdown.getAllSelectedOptions());

//		driver.findElement(By.cssSelector("input[placeholder='Type for hints...']")).sendKeys("manda");
//		List<WebElement> texts=driver.findElements(By.cssSelector("input[placeholder='Type for hints...']"));
//		for(WebElement text:texts )
//		{
//			if(text.getText().equalsIgnoreCase("manda AI_Orchestrator user"))
//			{
//				driver.findElement(By.className("oxd-autocomplete-text")).click();
//				break;
//			}
//		}
		
		
//		FluentWait<WebDriver> wait = new FluentWait<>(driver)
//			.withTimeout(Duration.ofSeconds(20))
//			.pollingEvery(Duration.ofSeconds(2))
//		    .ignoring(NoSuchElementException.class);
//			WebElement inputBox = wait.until(
//		d -> d.findElement(By.cssSelector("input[placeholder='Type for hints...']")));
//
//				inputBox.sendKeys("manda");
//
//				List<WebElement> options = driver.findElements(By.cssSelector(".oxd-autocomplete-option"));
//						for(WebElement option : options) {
//
//				String optionText = option.getText();
//	
//				System.out.println(optionText);
//
//				if (optionText.equalsIgnoreCase("manda AI_Orchestrator user")) {
//				
//				option.click();
//				
//				break;
				
				}
				

			}


