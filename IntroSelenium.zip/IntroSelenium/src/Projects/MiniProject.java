package Projects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class MiniProject {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2000));

		// Blank Field
		driver.findElement(By.name("username")).sendKeys("");
		driver.findElement(By.name("password")).sendKeys("");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		System.out.println(driver.findElement(By.cssSelector(".oxd-input-field-error-message")).getText());
		
		// Invalid username & password
		driver.findElement(By.name("username")).sendKeys("InAdmin");
		driver.findElement(By.name("password")).sendKeys("Inadmin123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		System.out.println(driver.findElement(By.cssSelector(".oxd-alert-content-text")).getText());

		// Valid Username & Password
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();

		//Click on Admin tab
		driver.findElement(By.xpath("//span[text()='Admin']")).click();
		
		//Click on Add button
		Actions a=new Actions(driver);
		WebElement username=driver.findElement(By.xpath("//div/button[text()=' Add ']"));
		a.moveToElement(username).click().build().perform();
		
		//User role
		driver.findElement(By.xpath("//label[text()='User Role']/ancestor::div[contains(@class,'oxd-input-group')]//div[contains(@class,'oxd-select-text-input')]")).click();
		driver.findElement(By.xpath("//span[normalize-space()='ESS']")).click();
		
		//Status
		driver.findElement(By.xpath("//label[text()='Status']/ancestor::div[contains(@class,'oxd-input-group')]//div[contains(@class,'oxd-select-text-input')]")).click();
		driver.findElement(By.xpath("//span[normalize-space()='Enabled']")).click();
		
		//Password
		driver.findElement(By.xpath("//label[text()='Password']/ancestor::div[contains(@class,'oxd-input-group')]//input[contains(@type,'password')]")).sendKeys("12345");
		driver.findElement(By.xpath("//label[text()='Password']/ancestor::div[contains(@class,'oxd-input-group')]//input[contains(@type,'password')]")).sendKeys("India@2026");
		
		//Username
		driver.findElement(By.xpath("//label[text()='Username']/ancestor::div[contains(@class,'oxd-input-group')]//input[contains(@class,'oxd-input')]")).sendKeys("username001");
		
		//Confirm Password
		driver.findElement(By.xpath("//label[text()='Confirm Password']/ancestor::div[contains(@class,'oxd-input-group')]//input[contains(@class,'oxd-input')]")).sendKeys("India");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//label[text()='Confirm Password']/ancestor::div[contains(@class,'oxd-input-group')]//input[contains(@class,'oxd-input')]")).clear();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//label[text()='Confirm Password']/ancestor::div[contains(@class,'oxd-input-group')]//input[contains(@class,'oxd-input')]")).sendKeys("India@2026");
		
		
		//Employee Name
		
//		driver.findElement(By.xpath("//input[@placeholder='Type for hints...']")).click();
//
//
//		List<WebElement> values = driver.findElements(By.xpath("//div[contains(@class,'oxd-autocomplete-dropdown')]"));
//
//
//		for(WebElement value : values) {
//
//		    if(value.getText().equals("Option 1")) {
//
//		        value.click();
//
//		        break;
//Save button
driver.findElement(By.xpath("//button[@type='submit']")).click();
//		
		
		
		//Employee name
//		WebElement text= driver.findElement(By.cssSelector("input[placeholder='Type for hints...']"));
//		text.sendKeys("manda");
//		Select dropdown=new Select(text);
//		
//		dropdown.selectByVisibleText("manda AI_Orchestrator user");
//		
		//.sendKeys("manda AI_Orchestrator user")
		//driver.findElement(By.xpath("//label[text()='Username']/parent::div/following-sibling::div/input"));
		//a.moveToElement(username).click().sendKeys("Sanjana").build().perform();
		
		//Size of dropdown
		//System.out.println(driver.findElements(By.className("oxd-topbar-body-nav-tab-item")).size());
	}

}
