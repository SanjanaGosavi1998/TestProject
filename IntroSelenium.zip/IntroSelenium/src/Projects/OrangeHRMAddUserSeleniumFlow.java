package Projects;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class OrangeHRMAddUserSeleniumFlow {

    private static final String BASE_URL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
    private static final String USERNAME = "Admin";
    private static final String PASSWORD = "admin123";

    private static final String USER_ROLE = "Admin";
    private static final String EMPLOYEE_SEARCH_TEXT = "Auto";
    private static final String EMPLOYEE_FULL_NAME = "AutoTest QAQALab Selenium";

    public static void main(String[] args) {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");

        WebDriver driver = new ChromeDriver(options);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

        try {
            login(driver, wait);
            navigateToAddUserPage(driver, wait);
            selectCustomDropdownOption(driver, wait, "User Role", USER_ROLE);
            selectEmployeeAutocomplete(driver, wait, EMPLOYEE_SEARCH_TEXT, EMPLOYEE_FULL_NAME);

            String selectedName = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//input[@placeholder='Type for hints...']")))
                    .getAttribute("value");

            System.out.println("Selected employee value: " + selectedName);
            System.out.println("Flow completed successfully.");
        } finally {
            driver.quit();
        }
    }

    private static void login(WebDriver driver, WebDriverWait wait) {
        driver.get(BASE_URL);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username"))).sendKeys(USERNAME);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("password"))).sendKeys(PASSWORD);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit']"))).click();

        wait.until(ExpectedConditions.urlContains("/dashboard"));
    }

    private static void navigateToAddUserPage(WebDriver driver, WebDriverWait wait) {
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/admin/viewSystemUsers");
        wait.until(ExpectedConditions.urlContains("/admin/viewSystemUsers"));
        wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//button[normalize-space()='Add']"))).click();
        wait.until(ExpectedConditions.urlContains("/admin/saveSystemUser"));
        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//h6[normalize-space()='Add User']")));
    }

    private static void selectCustomDropdownOption(WebDriver driver, WebDriverWait wait, String labelText, String optionText) {
        int dropdownIndex = "User Role".equals(labelText) ? 1 : 2;
        By dropdown = By.xpath("(//div[contains(@class,'oxd-select-text')])[" + dropdownIndex + "]");

        wait.until(ExpectedConditions.visibilityOfElementLocated(dropdown)).click();

        By option = By.xpath("//*[@role='listbox']//*[@role='option'][normalize-space()=\"" + optionText + "\"]");
        wait.until(ExpectedConditions.elementToBeClickable(option)).click();

        By selectedValue = By.xpath("(//div[contains(@class,'oxd-select-text-input')])[" + dropdownIndex + "]");
        wait.until(d -> {
            String value = d.findElement(selectedValue).getText().trim();
            return value.equals(optionText);
        });
    }

    private static void selectEmployeeAutocomplete(WebDriver driver, WebDriverWait wait, String searchText, String exactOptionText) {
        By inputBy = By.xpath("//input[@placeholder='Type for hints...']");
        WebElement input = wait.until(ExpectedConditions.elementToBeClickable(inputBy));

        input.click();
        input.clear();
        input.sendKeys(searchText);

        By listBox = By.xpath("//*[@role='listbox']");
        wait.until(ExpectedConditions.visibilityOfElementLocated(listBox));

        // Wait until the loading row is replaced with real options.
        waitForAutocompleteResults(driver, wait);

        By nonLoadingOptions = By.xpath(
                "//*[@role='listbox']//*[@role='option'][normalize-space()!='' and normalize-space()!='Searching....']");
        wait.until(d -> d.findElements(nonLoadingOptions).size() > 0);

        By exactOption = By.xpath(
                "//*[@role='listbox']//*[@role='option'][normalize-space()=\"" + exactOptionText + "\"]");

        WebElement target;
        List<WebElement> exactMatches = driver.findElements(exactOption);
        if (!exactMatches.isEmpty()) {
            target = exactMatches.get(0);
        } else {
            List<WebElement> fallback = driver.findElements(nonLoadingOptions);
            if (fallback.isEmpty()) {
                throw new TimeoutException("No selectable autocomplete option found for Employee Name.");
            }
            target = fallback.get(0);
        }

        String selectedText;
        try {
            selectedText = target.getText().trim();
        } catch (StaleElementReferenceException ex) {
            List<WebElement> refreshed = driver.findElements(nonLoadingOptions);
            if (refreshed.isEmpty()) {
                throw new TimeoutException("Autocomplete options refreshed and no option remained selectable.");
            }
            target = refreshed.get(0);
            selectedText = target.getText().trim();
        }

        if (selectedText.isEmpty()) {
            throw new TimeoutException("No selectable autocomplete option found for Employee Name.");
        }

        wait.until(ExpectedConditions.elementToBeClickable(target)).click();
        wait.until(ExpectedConditions.attributeToBe(inputBy, "value", selectedText));
    }

    private static void waitForAutocompleteResults(WebDriver driver, WebDriverWait wait) {
        By optionRows = By.xpath("//*[@role='listbox']//*[@role='option']");

        wait.until(d -> {
            List<WebElement> options = d.findElements(optionRows);
            if (options.isEmpty()) {
                return false;
            }

            for (WebElement option : options) {
                try {
                    String text = option.getText().trim();
                    if (!text.equalsIgnoreCase("Searching....")) {
                        return true;
                    }
                } catch (StaleElementReferenceException ignored) {
                    return false;
                }
            }
            return false;
        });

        try {
            wait.until(ExpectedConditions.invisibilityOfElementWithText(optionRows, "Searching...."));
        } catch (TimeoutException ignored) {
            // Some runs skip the loading row; safe to continue after at least one non-loading option appears.
        }
    }
}



