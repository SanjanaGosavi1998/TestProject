import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeventeenCookiesScreenshots {

	public static void main(String[] args) throws IOException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		
		driver.manage().window().maximize();
		
		
		//Delete Cookies
		driver.manage().deleteAllCookies();
		//driver.manage().deleteCookieNamed("SessionKey"); //Delete one single cookie
		
		//Screenshot
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C:\\Users\\SANGOSAV\\Desktop\\Sanjana Documents\\screenshot.png"));

	}

}
