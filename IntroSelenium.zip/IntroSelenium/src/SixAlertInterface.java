import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SixAlertInterface {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();

		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		driver.manage().window().maximize();

		// Simple Alert
		driver.findElement(By.id("alertbtn")).click();
		Thread.sleep(2000);
		// System.out.println(driver.switchTo().alert().getText());
		// or
		Alert a = driver.switchTo().alert();
		System.out.println(a.getText());
		Thread.sleep(2000);
		// driver.switchTo().alert().accept();
		// or
		a.accept();


		// Confirmation Alert
		driver.findElement(By.cssSelector("#confirmbtn")).click();
		Thread.sleep(2000);
		System.out.println(driver.switchTo().alert().getText());
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
		Thread.sleep(2000);

        //Prompt alert
		driver.findElement(By.xpath("//input[@id='name']")).sendKeys("Sanjana");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("input.btn-style")).click();
		Thread.sleep(2000);
		System.out.println(driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();


	}

}
