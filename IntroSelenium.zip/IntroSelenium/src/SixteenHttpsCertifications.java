import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class SixteenHttpsCertifications {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://expired.badssl.com/");
		System.out.println(driver.getTitle());
		//Output= Privacy error which is not the title so to handle this 
		
		ChromeOptions options=new ChromeOptions();
		options.setAcceptInsecureCerts(true);
		WebDriver driver1=new ChromeDriver(options);
		driver1.get("https://expired.badssl.com/");
		System.out.println(driver1.getTitle());
		
		
		

	}

}
