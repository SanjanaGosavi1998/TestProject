import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TenWaits {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		
		//Implicit Wait
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2000));
		
		
		//Explicit Wait
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(20));
		WebElement Serachbox=wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("span.promoInfo")));
		Serachbox.click();
		
		
		//Fluent Wait
		
		driver.get("https://www.google.com");
		
		FluentWait<WebDriver> wait1 = new FluentWait<>(driver)
				.withTimeout(Duration.ofSeconds(10))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class);
		
		WebElement searchBox = wait1.until(ExpectedConditions.elementToBeClickable(By.linkText("Gmail")));
		searchBox.click();
				
		
	}

}
