import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ThirteenLinks {

	public static void main(String[] args) {
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		//Link should have tagname ie. "a"
		
		//1. Give me count of links which present in whole page
		System.out.println(driver.findElements(By.tagName("a")).size());

		
		
		//2. Get me count of links which present in footer sessions
		//Limiting WebDriver Scope
		WebElement footerdriver=driver.findElement(By.id("gf-BIG"));
		System.out.println(footerdriver.findElements(By.tagName("a")).size()); //Instead of WebDriver used footerdriver for limiting scope in page
		
		//3. In footer 1st column link count I want
		WebElement columndriver=footerdriver.findElement(By.xpath("//table/tbody/tr/td[1]/ul"));
		System.out.println(columndriver.findElements(By.tagName("a")).size());
		
		//4. Click on each Tab links and check if the pages are opening
		for(int i=1;i<columndriver.findElements(By.tagName("a")).size();i++)
		{
			String ClickonLinkTab= Keys.chord(Keys.CONTROL, Keys.ENTER);
			columndriver.findElements(By.tagName("a")).get(i).sendKeys(ClickonLinkTab);
			
		}
		
		//5. Open all the tabs and grab the title
		Set<String> abc=driver.getWindowHandles();
		Iterator<String> it=abc.iterator();
		while(it.hasNext()) //check next tab is present or not
		{
			driver.switchTo().window(it.next());
			System.out.println(driver.getTitle());
		}
	}
	

}
