import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ThreeSiblingsTravelParentChildTravel {

	public static void main(String[] args) {
		
        WebDriver driver=new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		//This is not possible in cssSelector
		
		System.out.println(driver.findElement(By.xpath("//header/div/button[1]")).getText());
		
		//ParentTagname/ChildTagname/SubchildTagname[index]/following-sibling::subchildTagname[index]
		
		
		System.out.println(driver.findElement(By.xpath("//header/div/button[1]/following-sibling::button[2]")).getText());
		

		//Child-Parent Travel
		//ParentTagname/ChildTagname/SubchildTagname[index]--Present in one subchildtagname place
		//want to travel again to parent then we use /parent::tagname
		//ParentTagname/ChildTagname/SubchildTagname[index]/parent::tagname
		driver.findElement(By.xpath("//header/div/button[1]/parent::div/parent::header"));
		
		//Again parent to child then /Childtagname
		//Parent-child-parent = //header/div/button[1]/parent::div
		//Parent-child-parent/child = //header/div/button[1]/parent::div/button[2]
		driver.findElement(By.xpath("//header/div/button[1]/parent::div/button[2]"));

	}

}
