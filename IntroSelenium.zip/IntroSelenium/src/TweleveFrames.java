import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TweleveFrames {

	public static void main(String[] args) {
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://jqueryui.com/droppable/");
		driver.manage().window().maximize();
		
		//Iframe by using WebElement
		driver.switchTo().frame(driver.findElement(By.cssSelector(".demo-frame")));
		
		Actions a=new Actions(driver);
		WebElement source= driver.findElement(By.id("draggable"));
		WebElement target= driver.findElement(By.id("droppable"));
		a.dragAndDrop(source, target).build().perform();
		
		driver.switchTo().defaultContent(); //Comeout from iframe
		
		System.out.println(driver.findElements(By.tagName("iframe")).size());
		
		//By using frame index
		driver.switchTo().frame(0);
		

	}

}
