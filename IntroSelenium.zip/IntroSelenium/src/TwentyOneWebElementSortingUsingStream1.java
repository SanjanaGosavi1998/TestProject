import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TwentyOneWebElementSortingUsingStream1 {

	
	@Test
	public void coumnName() {
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
		driver.manage().window().maximize();

		//Scan the name column with text "Rice" which present in next pages. just grab from it
		
		List<String>price;
		do {
			List<WebElement> rows= driver.findElements(By.xpath("//tr/td[1]"));
			price= rows.stream().filter(s->s.getText().contains("Rice")).map(s->getPriceVeggie(s)).collect(Collectors.toList());
			price.forEach(a->System.out.println(a));
			if(price.size()<1) {
				driver.findElement(By.cssSelector("[aria-label='Next']")).click();
			}
		}while(price.size()<1);
	}
	private static String getPriceVeggie(WebElement s) {
		
		String priceValue= s.findElement(By.xpath("following-sibling::td[1]")).getText();

		return priceValue;

	}
	
	
	
	//Search Box I type "Rice" then in list rice should present
	
	@Test
	public void searchVeggie() {
	WebDriver driver=new ChromeDriver();
	driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
	driver.manage().window().maximize();
	
	driver.findElement(By.id("search-field")).sendKeys("Rice");
	List<WebElement> Veggies=driver.findElements(By.xpath("//tr/td[1]"));
	
	List<WebElement> filteredList= Veggies.stream().filter(s->s.getText().contains("Rice")).collect(Collectors.toList());
	Assert.assertEquals(Veggies.size(), filteredList.size());

}
}


