import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class TwentyWebelementSortingUsingStream {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
		driver.manage().window().maximize();

		//click on WebElement
		driver.findElement(By.xpath("//tr/th[1]")).click();
		
		//capture all WebElements into list
		List<WebElement> elementslist=driver.findElements(By.xpath("//tr/td[1]"));
		
		//capture text of all webelements into new(Original) list
		List<String> originalList=elementslist.stream().map(s->s.getText()).collect(Collectors.toList());
		
		//Sort on the original List 
		List<String> sortedList= originalList.stream().sorted().collect(Collectors.toList());
		
		//Compare originalList vs Sorted list
		Assert.assertTrue(originalList.equals(sortedList));
		
		
		//Scan the name column with getText()-> Beans-> Print the price of beans
		
		List<String> price= elementslist.stream().filter(s->s.getText().contains("Beans")).map(s->getPriceVeggie(s)).collect(Collectors.toList());
		
		price.forEach(a->System.out.println(a));
	}

	private static String getPriceVeggie(WebElement s) {
		
		String priceValue= s.findElement(By.xpath("following-sibling::td[1]")).getText();
	
		return priceValue;
	}
	}
	

