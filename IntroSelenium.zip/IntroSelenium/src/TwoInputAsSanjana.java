import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TwoInputAsSanjana {

	public static void main(String[] args) throws InterruptedException {
		
        String name="Sanjana";
		
		WebDriver driver=new ChromeDriver();
		String password= getPassword(driver);
		driver.findElement(By.xpath("//button[text()='Go to Login']")).click();
		driver.findElement(By.id("inputUsername")).sendKeys(name); //ID
		driver.findElement(By.name("inputPassword")).sendKeys(password); //name
		driver.findElement(By.cssSelector("input#chkboxTwo")).click(); //tagname#id by css
		driver.findElement(By.xpath("//button[contains(@class,'submit')]")).click();
		

	}
	
	public static String getPassword(WebDriver driver) throws InterruptedException
	{
		driver.get("https://rahulshettyacademy.com/locatorspractice/");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("Forgot your password?")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.cssSelector(".reset-pwd-btn")).click(); //.classname by css
		
        String PasswordText=driver.findElement(By.xpath("//div/form/p")).getText(); //Parent-child xpath
		
		String[] password= PasswordText.split("'");
		//0th=
		//1st=
		String[] password1 =password[1].split("'");
		String finalpass=password1[0];
		return finalpass ;
		

	}

}
