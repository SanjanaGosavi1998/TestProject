package javapackage;

public abstract class Abstraction1 {
	
	static int a =5; //Static variable
	int b=5; //Global variable
	final int c=10; //Final variable
	
	//Abstract method can not have a body
	abstract void eat();
	

}
