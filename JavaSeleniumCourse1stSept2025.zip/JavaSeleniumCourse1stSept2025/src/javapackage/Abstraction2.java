package javapackage;

public class Abstraction2 extends Abstraction1 {
    //abstract keyword not added in class name after public like previous Class
	
	void eat() {
		System.out.println("Abstraction method : eating");
	}

	public static void main(String[] args) {
		
		//Normal class is present that's why we create object
		Abstraction2 a2=new Abstraction2();
		a2.eat();
		
		System.out.println(a2.c);
		System.out.println(a2.b);
		System.out.println(a);
	}

}
