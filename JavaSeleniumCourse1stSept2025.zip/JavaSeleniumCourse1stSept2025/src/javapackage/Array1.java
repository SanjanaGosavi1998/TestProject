package javapackage;

public class Array1 {

	public static void main(String[] args) {
		
		//Defining a multi dimentional array
		int a[][]= {{1,2,3}, {4,5,6}, {7,8,9}};
		
		//Total no of rows
		int row=a.length;
		System.out.println("total no of rows are "+row);
		
		//Total no of columns
		int column=a[0].length;
		System.out.println("total no of columns are "+column);
		

	}

}
