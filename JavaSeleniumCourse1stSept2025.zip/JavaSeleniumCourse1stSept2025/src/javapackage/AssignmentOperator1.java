package javapackage;

public class AssignmentOperator1 {

	public static void main(String[] args) {
		
		int a=10;
		a+=5; //+= is symbol of assignment operator,Do not pass space
		System.out.println(a); //15
		
		a-=5;
		System.out.println(a); //10
		
		a*=3;
		System.out.println(a); //30
		
		a/=2;
		System.out.println(a); //15

	}

}
