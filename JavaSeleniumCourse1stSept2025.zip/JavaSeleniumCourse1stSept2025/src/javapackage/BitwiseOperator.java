package javapackage;

public class BitwiseOperator {

	public static void main(String[] args) {
		
		int x=2;
		int y=4;
		int z=6;
		
		//Bitwise Operator
		System.out.println(x>y & x<y); //False True =False
		System.out.println(++x>y & x<++y); //False True=False
		System.out.println(x);//3
		System.out.println(y);//5
		
		//Logical Operator--First condition is true then It will check second condition also
		System.out.println(x<y && ++x>y); //True False= False
		System.out.println(x); //4

	}

}
