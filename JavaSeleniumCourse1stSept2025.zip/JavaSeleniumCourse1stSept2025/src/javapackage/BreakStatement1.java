package javapackage;

public class BreakStatement1 {

	public static void main(String[] args) {
		
		//0 to 9 using for loop
		for(int i=0; i<10; i++) {
			
			//If Statement
			if(i==5) {
				break;
			}
			System.out.println(i);
		}

	}

}
