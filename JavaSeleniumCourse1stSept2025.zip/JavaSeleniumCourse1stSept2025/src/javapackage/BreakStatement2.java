package javapackage;

public class BreakStatement2 {

	public static void main(String[] args) {
		
		int a=10;
		
		while(a==10) {
			System.out.println("Value of a is 10");
			break;
		}

	}

}
