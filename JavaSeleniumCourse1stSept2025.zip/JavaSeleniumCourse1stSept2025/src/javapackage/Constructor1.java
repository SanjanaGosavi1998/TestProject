package javapackage;

public class Constructor1 {
	
	//Default constructor --Don't have any parameters inside constructor
	Constructor1(){
		System.out.println("Hello Constructor");
	}
	
    //Main method
	public static void main(String[] args) {
		Constructor1 c1=new Constructor1();

	}

}
