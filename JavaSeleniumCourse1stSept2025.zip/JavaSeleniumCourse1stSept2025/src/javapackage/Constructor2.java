package javapackage;

public class Constructor2 {
	
	//Default Constructor
	Constructor2(){
		System.out.println("Hello Default Constructor");
	}
	
	String name; //Declaring 
	String Address;
	
	//Parameterized Constructor
	Constructor2(String b, String c){
		name=b;
		Address=c;
		
		System.out.println(name +" "+ Address);
	}

	public static void main(String[] args) {
		
		Constructor2 c2=new Constructor2();
		Constructor2 c3=new Constructor2("Sanjana", "Mumbai");
		Constructor2 c4=new Constructor2("Tejas", "Sikkim");
		
		

	}

}
