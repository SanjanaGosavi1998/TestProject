package javapackage;

public class Constructor4 {
	
	int c;

	//Parameterized constructor
	Constructor4(int a, int b){
		c=a+b;
		System.out.println("Addition is "+ c);
	}
	
	Constructor4(int x, int y, int z){
		c=x*y*z;
		System.out.println("Multiplication is " +c);
	}
	
	Constructor4(){
		for (int i=0; i<=5; i++) {
			System.out.println(i);
		}
	}

	public static void main(String[] args) {
		
		Constructor4 c4=new Constructor4(5,10);
		Constructor4 c5=new Constructor4(5,5,5);
		Constructor4 c6=new Constructor4();
		

	}

}
