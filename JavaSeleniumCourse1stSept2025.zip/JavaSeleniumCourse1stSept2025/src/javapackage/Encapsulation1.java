package javapackage;

public class Encapsulation1 {
	
	String name; //Global declaring variable
	int a=5; //Global Defining variable
	final int b=50; 
	
	//User defined non static method
	public void a() {
		
		a=30;
		//b=25; //Final variable we can not change
		
	}
	
	//Final method
	final void d() {
		System.out.println("Hello final method");
	}
}
