package javapackage;

public class IfElse1 {

	public static void main(String[] args) {
		
		int a=15;
		
		//IF Statement
		if(a>10) {
			System.out.println("a>10");
		}

	}

}
