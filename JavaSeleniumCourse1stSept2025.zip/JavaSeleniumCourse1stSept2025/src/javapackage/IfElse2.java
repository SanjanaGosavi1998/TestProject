package javapackage;

public class IfElse2 {

	public static void main(String[] args) {
		
		int a=10;
		 if(a/3==5) {
			 System.out.println("Result of a=5");
		 }
		 else {
			 System.out.println("xyz");
		 }
	}

}
