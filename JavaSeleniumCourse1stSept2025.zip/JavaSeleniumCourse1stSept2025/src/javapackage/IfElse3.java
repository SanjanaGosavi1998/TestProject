package javapackage;

public class IfElse3 {

	public static void main(String[] args) {
		
		int q=40;
		int w=40;
		
		if(q>w) {
			System.out.println("q is greater than w");
		}
		else if(w>q) {
			System.out.println("w is grater than q");
		}
		else if(q==w) {
			System.out.println("q is equal to w");
		}
		else {
			System.out.println("q and w are different");
		}

	}

}
