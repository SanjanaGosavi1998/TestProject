package javapackage;

public class IfElse4 {

	public static void main(String[] args) {
		
		int age=17;
		int weight=45;
		
		//Outer if block
		if(age>18) {
			
			//Inner if block
			if (weight>50) {
				System.out.println("Yes, Candidate is eligible for Indian ARMY");
			}
			else {
				System.out.println("Not Eligible candidate");
			}
		}
		else {
			System.out.println("Not Eligible");
		}
		

	}

}
