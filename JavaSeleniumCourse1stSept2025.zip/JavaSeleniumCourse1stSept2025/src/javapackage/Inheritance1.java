package javapackage;

public class Inheritance1 {
	
	int d=10; //Global variable

	public static void main(String[] args) {
		

	}

}
