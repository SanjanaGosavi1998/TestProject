package javapackage;

public class Inheritance2 extends Inheritance1 {
	          //Child               //Parent
	
	int z=100; //Global variable

	public static void main(String[] args) {
		
		Inheritance2 i2=new Inheritance2(); 
		
		System.out.println(i2.z);
		System.out.println(i2.d);
		

	}

}
