package javapackage;

public class Inheritance4 {

	int z; // Declaring global variable

	// User defined non-static method with passing parameter in bracket
	public void addition(int x, int y) {

		z = x + y; // Establishing a relation
		System.out.println("Addition is " + z);

	}

	// Non-Static method
	public void substraction(int x, int y) {
		// Passing parameters in bracket

		z = x - y; // Establishing a relation
		System.out.println("Substraction is " + z);

	}

	// Static Method
	public static void multiplication(int x, int y) {
		int a = x * y;
		
		//We can not use global variable in static method 
		//so for Static method we are creating Local variable
		//If you want to use global variable, then the method should be non-static
		System.out.println("Multipication is " + a);
	}

}
