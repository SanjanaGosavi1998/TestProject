package javapackage;

public class Inheritance5 extends Inheritance4 {

	public static void main(String[] args) {
		
		int x=100;
		int y=50;
		
		Inheritance5 i5=new Inheritance5();
		
		i5.addition(10,20); //Other way to print addition method
		
		i5.addition(x, y);
		i5.substraction(x, y);
		
		//Calling Static method
		i5.multiplication(x, y);
		multiplication(x, y);
		
		

	}

}
