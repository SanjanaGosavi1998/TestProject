package javapackage;

public class InheritancePractice1 {
	
	String s="Sayali";
	
	public void display() {
		System.out.println(s);
	}
	
	public void name(String firstname, String lastname) {
		System.out.println("Full name is "+ firstname + lastname);
		
	}

	public void character(char x, char y) {
		System.out.println(x);
		System.out.println(y);
		
		
	
	}

}
