package javapackage;

public class InheritancePractice2 extends InheritancePractice1 {
	
	int rollno=20;
	public void show() {
		System.out.println(rollno);
	}
	
	public static void course() {
		System.out.println("Selenium");
	}
	

	public static void main(String[] args) {
		
		InheritancePractice2 i2= new InheritancePractice2();
		
		i2.display();
		
		
		i2.show();
		
		course();
		
		i2.name("Sanjana", " Gosavi");
		
		i2.character('t', 'o');

	}

}
