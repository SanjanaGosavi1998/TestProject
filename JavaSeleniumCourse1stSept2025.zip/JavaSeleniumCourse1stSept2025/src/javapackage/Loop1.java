package javapackage;

public class Loop1 {

	public static void main(String[] args) {
		
		//We want to print 0 to 5 using for loop
		for (int i=0; i<6; i++) {
			System.out.println(i); //0,1,2,3,4,5
		}
		
		//Print 10 to 20 numbers by using for loop
		for (int i=10; i<=20; i++) {
			System.out.println(i); //10,11,12,13,14,15,16,17,18,19,20
		}
		System.out.println("control came out of the loop");
		
		//1 3 5 7 9
		for (int i=1; i<10; i+=2) {
			System.out.println(i); //1 3 5 7 9
		}
	}

}
