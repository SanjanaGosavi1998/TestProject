package javapackage;

public class Loop2 {

	public static void main(String[] args) {
		
		Object a[]= {1,2,3,"Java",'c','g',2>3};
		
		//Print an array using for each loop
		
		for (Object b:a) {
			System.out.println(b);
		}

	}

}
