package javapackage;

public class Loop3 {

	public static void main(String[] args) {

		int i = 10; //Local Variable

		// Print number 10-14 using while loop

		while (i < 15) {
			System.out.println(i);
			i++;
		}

	}

}
