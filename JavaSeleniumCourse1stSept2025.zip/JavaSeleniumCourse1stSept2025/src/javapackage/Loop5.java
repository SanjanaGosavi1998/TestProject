package javapackage;

public class Loop5 {

	public static void main(String[] args) {
		
		//5-10 by using while loop
		int h=5;
		
		while(h<11) {
			System.out.println(h);
			h++;
		}

	}

}
