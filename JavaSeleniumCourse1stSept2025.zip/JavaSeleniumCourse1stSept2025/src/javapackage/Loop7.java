package javapackage;

public class Loop7 {

	public static void main(String[] args) {
		
		//25 to 35
		int d=25;
		do {
			System.out.println(d);
			d++;
		}
		while(d<36);

	}

}
