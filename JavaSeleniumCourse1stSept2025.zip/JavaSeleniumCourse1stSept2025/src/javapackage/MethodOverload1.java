package javapackage;

public class MethodOverload1 {

	//non-static method
	public void sum(int a,int b) {
		System.out.println(a+b);
	}
	//public void sum(int a,int b) {
		//System.out.println(a+b); //Error 
	//}
	
	//Method name should be same but parameters should be different that is method overloading
	public void sum(int a, int b, int c) {
		System.out.println(a+b+c);
		
	}

}
