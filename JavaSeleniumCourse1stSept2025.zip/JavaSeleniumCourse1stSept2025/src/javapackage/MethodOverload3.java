package javapackage;

public class MethodOverload3 {
	

	//User defined static method
	public static void add(int a, int b) {
		System.out.println(a+b);
	}
	
	//If instead of void we are using int we have to give return statement instead of syso
	public static int add(int a, int b, int c) {
		return a+b+c;
		}

}
