package javapackage;

public class MethodOverload4 extends MethodOverload3{

	public static void main(String[] args) {
		
		//Syso is already present in method
		MethodOverload3.add(10, 10);
		
		
		//Using syso statement bcoz In MethodOverload3 used return statement which used to store value not print 
		System.out.println(MethodOverload3.add(10, 10, 10));
		

	}

}
