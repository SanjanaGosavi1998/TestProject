package javapackage;

public class MethodOverload5 {
	

	//Non-Static 
	public void java(int a) {
		System.out.println(a);
	}

	public void java(String s) {
		System.out.println(s);
	}
}

