package javapackage;

public class MethodOverload6 extends MethodOverload5 {

	public static void main(String[] args) {
		
		MethodOverload6 m5=new MethodOverload6();
		m5.java(10);
		m5.java("Java Method");
		

	}

}
