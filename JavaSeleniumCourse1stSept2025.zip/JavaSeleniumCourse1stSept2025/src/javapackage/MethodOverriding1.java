package javapackage;

public class MethodOverriding1 {

	public void eat() {
		System.out.println("Eating");
	}

}
