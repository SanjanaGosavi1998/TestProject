package javapackage;

public class MethodOverriding2 extends MethodOverriding1 {
	
	public void eat() {
		System.out.println("Eating again");
	}
	//Method and parameter both are same

	public static void main(String[] args) {
		
		MethodOverriding2 m2=new MethodOverriding2();
		m2.eat();
		
		MethodOverriding1 m1=new MethodOverriding1();
		m1.eat();
	}

}
