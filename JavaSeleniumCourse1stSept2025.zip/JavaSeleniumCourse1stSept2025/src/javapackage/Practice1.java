package javapackage;

public class Practice1 {
	
	int t=400;//Global variable
	static int w=700;//Static variable
	

	public static void main(String[] args) {
		
		//Override concepts
		int a=10;
		System.out.println(a);
		
		a=20;
		System.out.println(a);
		
		//Boolean conditions
		System.out.println(3>10); //false
		
		int b=100;
		int c=200;
		System.out.println(b<c);
		
		//Length of string
		String s="Hello";
		System.out.println(s.length());//First method
		
		int stringof = s.length();
		System.out.println(stringof);//Second method
		
		//Array
		int m[]= {1,2,3,4}; //int type array
		String n[]= {"java","of","Selenium"}; //string type array
		Object o[]= {5,6,7,'a','b',"Sanja"}; //combination of array
		
		System.out.println(m[2]); //3
		System.out.println(n[0]); //java
		System.out.println(o[4]); //b	
		
		//To execute user defined method program
		Selenium();

		//Defining a variable,Declaring a variable,Calling a variable
		int x=300; //Defining a variable
		int h;  //Declaring a variable
		int y=x; //Calling a variable
		System.out.println(y);
		
		//Float
		float e=3;
		System.out.println(e);
		
		//Print static variable
		System.out.println(w);
		
		//To print Global variable 
		Practice1 v= new Practice1();
		System.out.println(v.t);
	}

	//User defined method 
	public static void Selenium() {
		int l=100;
		System.out.println(l);
	}
}
