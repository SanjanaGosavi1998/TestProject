package javapackage;

public class Practice2 {

	public static void main(String[] args) {

		Class11(); //Calling User defined static method
		
		Practice2 f=new Practice2(); //Create an Object
		f.Class20(); //calling User defined non-static method
	}
	
	//User defined Static method
	public static void Class11() {
		int a=2;
		System.out.println(a);
	}
	
	//User defined non-static method
	public void Class20() {
		char n='g';
		System.out.println(n);
	}
}
