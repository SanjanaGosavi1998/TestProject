package javapackage;

public class Practice3 {

	public static void main(String[] args) {
		
		int age=20;
		int weight=45;
		
		if(age>18 & weight>55) {
			System.out.println("Selected in Army");
		}
		else {
			System.out.println("Not eligible");
		}
	}

}
