package javapackage;

public class Practice4 {

	public static void main(String[] args) {
		
		int a=10;
		int b=20;
		System.out.println(++a); //11
		System.out.println(a++); //11 12
		System.out.println(a); //12
		System.out.println(--a); //11 11
		System.out.println(a--); //11 10
		System.out.println(a); //10
		
		System.out.println(++a + a++); //11 11 + 11 12 =22
		System.out.println(a); //12
		System.out.println(--b - a++);//19 19 - 12 13 =7
		System.out.println(b); //19
		System.out.println(b-- + --b); //19 18 + 17 17 = 36
		
		System.out.println(a>b && b>a);
		System.out.println(a<b && b>a);
		System.out.println(a<b & b<a);
		
		
		
		
		
		
	}

	
}
