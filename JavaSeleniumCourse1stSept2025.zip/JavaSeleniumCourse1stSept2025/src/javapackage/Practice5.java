package javapackage;

public class Practice5 {
	int a=20; //Global varibale
	static int b=20; //Static varibale
	int roll;
	int sum;
	
	

	public static void main(String[] args) {
		int c=30; //Local Defining varibale
		int f; //Declaring varibale
		char d='g';
		String e="Sanjana";
		String h="Java Welcome";
		
		
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		
		System.out.println(e.length());
		System.out.println(h.length());
		
		int j=h.length();
		System.out.println(j);
		
		int k[]= {1,2,3,4,5};
		String l[]= {"java","welcome","of"};
		char m[]= {'q','e','r'};
		Object o[]= {9,8,7,"Sanja","t"};
		System.out.println(k[2]);//3
		System.out.println(l[0]);//java
		System.out.println(m[2]);//r
		System.out.println(o[3]);//Sanja
		
		int v=40;
		System.out.println(v>c);
		System.out.println(5>6);
		v=50;
		System.out.println(v);//50
		
		System.out.println(b); //20
		Practice5 s1=new Practice5();
		System.out.println(s1.a); //20
		s1.method3();
		
		s1.sum=200;
		System.out.println(s1.sum);
		
		
		System.out.println(s1.roll);
		
		method1();
		s1.method2();
		
		float z=6;
		System.out.println(z);
		
		//Arithmatic varibale
		int n=10;
		int u=20;
		System.out.println(n+u);
		System.out.println(n-u);
		System.out.println(n*u);
		System.out.println(n/u);
		
		//Unary Variable
		System.out.println(n++); //10 11
		System.out.println(++n); //12 12
		System.out.println(--u); //19 19
		System.out.println(u--); //19 18
		System.out.println(n); //12
		System.out.println(u); //18
		System.out.println(n++ + ++u); //12 13 +19 19= 31
		System.out.println(++n - u--); //14 14 - 19 18 =-5
		System.out.println(n); //14
		
		
		//Logical and Bitwise variable
		System.out.println(u>n && n<u);//True
		System.out.println(n>u & u<n); //False
		
		//Assignment Operator
		n+=5;
		System.out.println(n); 
		u-=5;
		System.out.println(u);
		
		
		
		

	}

	//USer defined static method
	public static void method1() {
		String n="Tejas";
		System.out.println(n);
	}
	//User defined non-Static method
	public void method2() {
		String x="AnaghaSayali";
		System.out.println(x);
	}
	public void method3() {
		System.out.println(sum);
	}
}
	
