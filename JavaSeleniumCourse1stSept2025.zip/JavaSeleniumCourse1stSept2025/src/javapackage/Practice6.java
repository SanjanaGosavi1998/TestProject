package javapackage;

public class Practice6 {

	public static void main(String[] args) {
		int a=5;
		int b=5;
		//Arithmetic 
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a*b);
		System.out.println(a/b);
		//Unary
		System.out.println(a);
		System.out.println(a++);//5 6
		System.out.println(++a); //7 7
		System.out.println(++a + a++); //8 8 + 8 9=16
		System.out.println(a);
		//Logical and Bitwise
		System.out.println(a>b && b>a); 
		System.out.println(a>b & b>a);
		//Assignment 
		a+=5;
		System.out.println(a);
		a-=6;
		System.out.println(a);
		a*=5;
		System.out.println(a);
		a/=5;
		System.out.println(a);
		//Relational 
		//If statement
		if(a>b) {
			System.out.println("a is greater than b");
		}
		//If-else statement
		if(b>a) {
			System.out.println("b is greater than a");
		}
		else {
			System.out.println("a is greater than b");
		}
		//If else ladder statement
		if(a>b) {
			System.out.println("a is greater than b");
		}
		else if(a==b) {
			System.out.println("a is equals to b");
		}
		else if(b>a) {
			System.out.println("b is greater than a");
		}
		else {
			System.out.println("a and b is different");
		}
		//nested if 
		int age=35;
		int weight=65;
		if(age>18) {
			if(weight>55) {
			System.out.println("Candidate is eligible");
			}
		}
		//0-9 print numbers for loop
		for(int i=0; i<=9; i++) {
			System.out.println(i);
		}
		//To print array using For each loop
		Object o[]= {"Sanjan",'g',1,2,3};
		for(Object c:o) {
			System.out.println(c);
		}
		//While Loop 20-30 numbers print
		int i=20;
		while(i<=30) {
			System.out.println(i);
			i++;
		}
		//Do-while loop 45-55
		int p=45;
		do {
			System.out.println(p);
			p+=2;
		}
		while(p<=55);
		
	}
	}
