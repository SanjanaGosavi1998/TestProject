package javapackage;

public class Practice7 {

	int a; // Global variable
	String s = "Sanjana";

	final int l = 60;

	public void add(int x, int y) {
		a = x + y;
		System.out.println("Addition is " + a);
	}

	public static void sub(int x, int y) {
		int v;
		v = x - y;
		System.out.println("Subtraction is " + v);
	}

	// Overloading
	public void add(int a, int b, int c) {
		System.out.println(a + b + c);
	}

	// Method Overriding
	public void eat() {
		System.out.println("Eat");
	}

	// Return statement
	public static int Multiply(int f, int g, int h) {
		return f * g * h;
	}

	// Final method
	final void n() {
		System.out.println("Encapsulation final method");
	}
}
