package javapackage;

public class Practice8 extends Practice7 {
	
	char i='t';
	
	public void eat() {
		System.out.println("Eating again");
	}

	public static void main(String[] args) {
		
		Practice8 p1= new Practice8();
		Practice7 p2=new Practice7();
		
		System.out.println(p1.i);
		System.out.println(p1.s);
		p1.add(10, 10);
		sub(30, 10);
		p1.add(10, 20, 30);
		p1.eat();
		p2.eat();
		
		//No need object for static using return
		System.out.println(Practice7.Multiply(5, 5, 5));
		
		System.out.println(p1.l);
		
		p1.n();
	}

}
