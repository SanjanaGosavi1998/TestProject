package javapackage;

public class RelationalOperator1 {

	public static void main(String[] args) {
		
		int a=100;
		int b=100;
		
		if (a!=b) {
			System.out.println("a is not equals to b");
		}
		else {
			System.out.println("a is equals to b");
		}
		
		String p="hello";
		String q="HELLO";
		
		//== is used to compare numbers not strings
		//Not recommended way to compare strings
		if (p==q) {
			System.out.println("p and q are same");
		}
		else {
			System.out.println("p and q are different");
		}
		
		//Comparing a strings in correct way
		if(p.equalsIgnoreCase(q)) {
			System.out.println("p and q are same");
		}
		else {
			System.out.println("p and q are different");
		}
		
	}

}
