package javapackage;

public class RelationalOperator2 {

	public static void main(String[] args) {
		
		String s="Selenium";
		String g="selenium";
		
		int f=5;
		int h=5;
		
		if (s.equalsIgnoreCase(g)){
			System.out.println("s==g"); //s==g
		}
		else {
			System.out.println("s!=g");
		}

		if(f==h) {
			System.out.println("f and h are same"); //print output
		}
		else {
			System.out.println("f and h are different");
		}
	}

}
