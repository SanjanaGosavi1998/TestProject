package javapackage;

public class TypeCastingNarrowing {

	public static void main(String[] args) {
		
		double b=5.2; //Local variable
		
		//Double to int
		int a=(int) b; //Manual casting from double to int
		
		System.out.println(b); //5.2
		System.out.println(a); //5
		
		//String to integer
		String s="10";
		int i=Integer.parseInt(s);
		System.out.println(i);
		
		//Integer to string
		int x=20;
		String y=String.valueOf(x);
		System.out.println(y);

	}

}
