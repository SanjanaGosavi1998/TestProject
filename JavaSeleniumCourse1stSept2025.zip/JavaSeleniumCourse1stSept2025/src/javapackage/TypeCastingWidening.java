package javapackage;

public class TypeCastingWidening {

	public static void main(String[] args) {
		
		int a=5; //Local 
		
		//int to double
		
		double b=a;
		System.out.println(a); //5
		System.out.println(b); //5.0
	}

}
