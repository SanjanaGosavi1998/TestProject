package javapackage;

public class UnaryOperator2 {

	public static void main(String[] args) {
		
		int a=10;
		int b=10;
		
		System.out.println(a++  +  ++a); //10,11 + 12,12
		                                  //10+12=22 (First and third value)
		System.out.println(a); //12
		System.out.println(++a + ++a); //13,13 + 14,14
		                                //13+14=27
	}

}
