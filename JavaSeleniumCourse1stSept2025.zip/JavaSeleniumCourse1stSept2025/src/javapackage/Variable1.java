package javapackage;

public class Variable1 {
    
	//Main body
	public static void main(String[] args) {
		System.out.println("Welcome to java course");
		
		System.out.println("package-Keyword & javapackage-package name");
		System.out.println(";-It is an completion of statement");
		System.out.println("public class-Keyword & Variable1-Classname");
		System.out.println("public static void main- main method");
		System.out.println("public static void-Keyword & main-method name");
		System.out.println("system-class & out-printstream object & println-method name & welcome-string argument");
		
		//new line 
		System.out.println("Sanjana \nTejas");
		
		

	}

}
