package javapackage;

public class Variable11 {

	int b=10; //Global variable
	char k= 'h'; //Global variable
	static int s=20; //Static variable
	
	public static void main(String[] args) {
		
		//for Global variable output created Object statement
		Variable11 v = new Variable11();
		
		int a =5; //Local variable
		
		System.out.println(a); //5
		System.out.println(s); //20
		System.out.println(v.b); //10 Not getting this in output so you need to create Object statement
		System.out.println(v.k); //h
	}

}
