package javapackage;

public class Variable12 {
	
	int a=5; //Global variable
	String s="java"; //Global variable

	//Static main method
	public static void main(String[] args) {
		

		String b="Selenium"; //Local variable
		System.out.println(b); //Calling b variable
		
		Variable12 s1=new Variable12(); //Object creation statement
		
		System.out.println(s1.a); //5
		System.out.println(s1.s); //java
		
		s1.method1(); //Non-static main method calling
		
		
	}

	//non static method
	public void method1(){
		int i=10; //Local variable
		System.out.println(i); //calling i variable
	}
}
