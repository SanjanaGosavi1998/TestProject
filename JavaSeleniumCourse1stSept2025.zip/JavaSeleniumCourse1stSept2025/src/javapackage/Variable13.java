package javapackage;

public class Variable13 {
	int roll; //Declaring a global variable
	String name; //Declaring a global variable
	static String college; //Declaring a static variable

	public static void main(String[] args) {
		
		Variable13 s2=new Variable13();
		
		System.out.println(s2.roll);  //0
		System.out.println(s2.name);  //Null
		System.out.println(s2.college); //Null
		System.out.println(college);    //Null
	}

}
