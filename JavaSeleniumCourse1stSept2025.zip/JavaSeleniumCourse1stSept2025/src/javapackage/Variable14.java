package javapackage;

public class Variable14 {
	static String s="hello"; //Static variable

	public static void main(String[] args) {
		int a=5; //Local variable
		 
		System.out.println(a); //5
		System.out.println(s); //hello
		

	}

}
