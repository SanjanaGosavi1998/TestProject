package javapackage;

public class Variable15 {
	
	int roll; //Declaring global variable
	String name; //Declaring global variable
	static String college="IIT Delhi"; //Defining a static variable
	
	//Constructor
	Variable15(int r, String n){
		roll=r;
		name=n;
	}
	
	//User non static defined method
	public void getResult() {
		System.out.println(roll + " " + name + " "+ college);
	}
	
	public static void main(String[] args) {
		Variable15 s4=new Variable15(1, "john");
		Variable15 s5=new Variable15(2, "Alex");
		Variable15 s6=new Variable15(3, "Peter");
		
		s4.getResult();
		s5.getResult();
		s6.getResult();
		
		
		

	}

}
