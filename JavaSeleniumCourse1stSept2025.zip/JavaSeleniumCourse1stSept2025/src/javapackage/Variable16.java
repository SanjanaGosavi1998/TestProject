package javapackage;

public class Variable16 {
	
	static int z=5; //Static global variable
	int y=1; //Global variable
	
	//User defined static method
	public static void a() {
		z=10; //Modifying the value of z 
		System.out.println(z); //10
	}

	//User defined non static method
	public void b() {
		z=15; //Modifying the value of z
		System.out.println(z); //15
	}
	
	public static void main(String[] args) {
		a(); //Calling User defined Static method output
		
		Variable16 s5=new Variable16(); //Create Object for User defined non static method output
		s5.b();
		
	}

}
