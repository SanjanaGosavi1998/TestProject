package javapackage;

public class Variable17 {
	
	int x=10; //Global variable
	static int y=5; //Static variable
	
	//User defined non-static method
	public void a() {
		int z=10; //Local variable
		System.out.println(z); //10
	}
	
	static int b=100; //Static variable

	public static void main(String[] args) {
		Variable17 s6= new Variable17(); //Create object for output of non static variable
		s6.a();
		
		System.out.println(b); //Correct way
		System.out.println(y); //Correct Way
		System.out.println(s6.b); //Not recommended
		System.out.println(Variable17.b); ////Not recommended
	}

}
