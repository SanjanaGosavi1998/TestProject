package javapackage;

public class Variable18 {
	
	String a; //Declaring a global variable
	int b; //Declaring a global variable
	static int c; //Declaring a static variable

	public static void main(String[] args) {
		
		Variable18 s7=new Variable18(); //For Global variable create Object
		s7.a="Selenium";
		s7.b=10;
		c=20;
		
		System.out.println(s7.a +" " +s7.b +" "+c);
		
		System.out.println(s7.a);
		System.out.println(s7.b);
		System.out.println(c);
		
		a();
	}

	public static void a() {
		System.out.println("Hello static method");
	}
}
