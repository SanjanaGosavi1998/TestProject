package javapackage;

public class Variable2 {
	
	int e=5;  //Global variable
	static int f=10;  //static variable
	
	
    //main method or Pre defined method
	public static void main(String[] args) {
		int d=2;   //Local variable
		System.out.println("Hello main method"); //Only main method is allow to getting printed

	}

	//User defined method
	public static void amethod() {
		System.out.println("Hello a method"); //Not getting print
		
	}
	
	public static void bmethod() {
		System.out.println("Hello b method"); //Not getting print
	}
}
