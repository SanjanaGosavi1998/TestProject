package javapackage;

public class Variable3 {

	public static void main(String[] args) {
		
		//All local variable
		int a=20;  //Defining a variable
		int y;     //Declaring a variable
		int sum=30;  //Identifier or variable
		String s ="Selenium";  //String variable. String consider in double quotes
		char c='g'; //Char considered in single quote. Only single char we can pass in char.
		
		//Calling variable to print its value
		System.out.println(a);    //20 
		System.out.println(sum);  //30
		System.out.println(s);    //Selenium
		System.out.println(c);    //g

	}

}
