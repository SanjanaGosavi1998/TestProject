package javapackage;

public class Variable4 {

	public static void main(String[] args) {
		String s="Hello";
		String b="Hello java";
		String v="You are beautiful";
		
		//How to calculate the length of string
		System.out.println(s.length());  //5
		System.out.println(b.length());  //10 Consider Space also
		System.out.println(v.length());  //17

	}

}
