package javapackage;

public class Variable5 {

	public static void main(String[] args) {
		//If wanted to print 1-10 so Array is used
		int a[]= {1,2,3,4,5,6};     
		
		System.out.println(a[0]);  //1     Considered from 0th position
		System.out.println(a[1]);  //2
		System.out.println(a[2]);  //3
		System.out.println(a[5]);  //6
		

	}

}
