package javapackage;

public class Variable6 {
    
	//type ma then ctrl space
	public static void main(String[] args) {
		int a=5;  //Local variable
		System.out.println(a); //Calling a variable to print its value :5
		
		int c=100; //Local variable
		System.out.println(c); //100
		
		c=200; //Local variable (Over-riding the value of c)
		System.out.println(c);
		
		char e='g'; //char type local variable
		System.out.println(e); //g
		
		boolean b= true;
		System.out.println(b); //true
		b=false; //Over-riding 
		System.out.println(b); //false
		
		System.out.println(3>10); //false
		
		int f=100;
		int h=200;
		boolean i=f>h; //false
		boolean k=f<h; //True
		System.out.println(i);
		System.out.println(k);
		System.out.println(f>h);

		

	}

}
