package javapackage;

public class Variable7 {

	public static void main(String[] args) {
		String s="Hello Selenium"; //Local variable
		
		System.out.println(s.length()); //14
		
		//Another method to calculate the length of string parameter s
		//Output should be in int format 
		
		int lengthofs = s.length();
		System.out.println(lengthofs);

	}

}
