package javapackage;

public class Variable8 {

	//Pre-defined main method
	public static void main(String[] args) {
		int a[] = {1,2,3,4,5,6}; //int type array
		String s[] = {"Hello","welcome","to","java","Selenium"}; //String type array
		
		//Object can hold all types of data types inside an array
		Object b[] = {0,12,13,'c','t',"Collage",3>10};
		
		System.out.println(a[3]); //4
		System.out.println(s[4]); //Selenium
		System.out.println(b[3]); //c
		System.out.println(b[2]); //13
		System.out.println(b[0]); //0
		System.out.println(b[5]); //Collage
		System.out.println(b[6]); //False
		
		java(); //Calling java method inside main method
	}

	//User defined static method
	public static void java(){
		int z=30; //Local variable
		System.out.println(z); //30 		
	}
	}
