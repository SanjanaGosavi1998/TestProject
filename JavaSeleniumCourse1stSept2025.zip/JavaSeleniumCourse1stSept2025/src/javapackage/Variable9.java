package javapackage;

public class Variable9 {

	public static void main(String[] args) {
		int a=100; 
		System.out.println(a); //Calling a variable to prints its value
		
		//Calling a variable to initialize to b variable
		int b=a;
		System.out.println(b); //100 
		
		
		int f; //Declaring a local variable
		int g=5; //Defining a local variable
		System.out.println(g); //calling a variable

	}

}
