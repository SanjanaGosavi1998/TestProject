package base;
 
import java.time.Duration;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
 
public class BaseClass {
 
	//What is driver? =Represents the browser., Used to perform actions on the browser.
	//Why protected? = Accessible within the same package. Accessible by child classes extending BaseClass.
	
    protected WebDriver driver;
    protected WebDriverWait wait;
 
    @BeforeMethod
    // Browser setup
    public void setUp() {
 
        driver = new ChromeDriver();
 
        driver.manage().window().maximize();
 
        // Implicit wait
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
 
        // Explicit wait object
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
 
        // Open application
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
    }
 
    @AfterMethod
    // Close browser
    public void tearDown() {
 
       if (driver != null) {
            driver.quit();
        }
    }
}