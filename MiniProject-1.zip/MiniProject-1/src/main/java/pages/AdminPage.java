package pages;
 
import java.time.Duration;
import java.util.List;
 
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
 
public class AdminPage {
 
    WebDriver driver;
    WebDriverWait wait;
 
 
    // =========================================================
    // LOCATORS
    // =========================================================
 
    // Admin Tab
    private By adminTab = By.xpath("//span[normalize-space()='Admin']");
 
 
    // Add Button
    private By addButton = By.xpath("//button[normalize-space()='Add']");
 
 
    // User Role Dropdown
    private By userRoleDropdown = By.xpath(
                "//label[normalize-space()='User Role']" +
                "/ancestor::div[contains(@class,'oxd-input-group')]" +
                "//div[contains(@class,'oxd-select-text')]");
 
 
    // ESS Option
    private By essOption = By.xpath("//*[@role='option'][normalize-space()='ESS']");
 
 
    // Status Dropdown
    private By statusDropdown =
            By.xpath(
                "//label[normalize-space()='Status']" +
                "/ancestor::div[contains(@class,'oxd-input-group')]" +
                "//div[contains(@class,'oxd-select-text')]"
            );
 
 
    // Enabled Option
    private By enabledOption = By.xpath("//*[@role='option'][normalize-space()='Enabled']");
 
 
    // Password
    private By passwordField =
            By.xpath(
                "//label[normalize-space()='Password']" +
                "/ancestor::div[contains(@class,'oxd-input-group')]" +
                "//input[@type='password']"
            );
 
 
    // Username
    private By usernameField =
            By.xpath(
                "//label[normalize-space()='Username']" +
                "/ancestor::div[contains(@class,'oxd-input-group')]" +
                "//input[contains(@class,'oxd-input')]"
            );
 
 
    // Confirm Password
    private By confirmPasswordField =
            By.xpath(
                "//label[normalize-space()='Confirm Password']" +
                "/ancestor::div[contains(@class,'oxd-input-group')]" +
                "//input"
            );
 
 
    // Employee Name
    private By employeeNameField = By.xpath("//input[@placeholder='Type for hints...']");
 
 
    // Employee autocomplete list
    private By employeeListBox = By.xpath("//*[@role='listbox']");
 
 
    // Employee autocomplete options
    private By employeeOptions =
            By.xpath(
                "//*[@role='listbox']" +
                "//*[@role='option']" +
                "[normalize-space()!='']" +
                "[normalize-space()!='Searching....']"
            );
 
 
    // Save Button
    private By saveButton = By.xpath("//button[@type='submit' and normalize-space()='Save']");
 
 
    // Success Toast
    private By successMessage = By.cssSelector(".oxd-toast-content-text");
 
 
    // =========================================================
    // CONSTRUCTOR
    // =========================================================
 
    public AdminPage(WebDriver driver) {
 
        this.driver = driver;
 
        this.wait = new WebDriverWait(driver,Duration.ofSeconds(20));
    }
 
 
    // =========================================================
    // ADMIN TAB
    // =========================================================
 
    public void clickAdminTab() {
 
        wait.until(ExpectedConditions.elementToBeClickable(adminTab)).click();
    }
 
 
    // =========================================================
    // ADD BUTTON
    // =========================================================
 
    public void clickAddButton() {
 
        wait.until(ExpectedConditions.elementToBeClickable(addButton)).click();
    }
 
 
    // =========================================================
    // USER ROLE - ESS
    // =========================================================
 
    public void selectUserRoleAsESS() {
 
        wait.until(ExpectedConditions.elementToBeClickable(userRoleDropdown)).click();
 
        wait.until(ExpectedConditions.elementToBeClickable(essOption)).click();
    }
 
 
    // =========================================================
    // STATUS - ENABLED
    // =========================================================
 
    public void selectStatusAsEnabled() {
 
        wait.until(ExpectedConditions.elementToBeClickable(statusDropdown)).click();
 
        wait.until(ExpectedConditions.elementToBeClickable(enabledOption)).click();
    }
 
 
    // =========================================================
    // PASSWORD
    // =========================================================
 
    public void enterPassword(String password) {
 
        WebElement field =wait.until(ExpectedConditions.visibilityOfElementLocated(passwordField));
 
        field.clear();
 
        field.sendKeys(password);
    }
 
 
    // =========================================================
    // USERNAME
    // =========================================================
 
    public void enterUsername(String username) {
 
        WebElement field = wait.until(ExpectedConditions.visibilityOfElementLocated(usernameField));
 
        field.clear();
 
        field.sendKeys(username);
    }
 
 
    // =========================================================
    // CONFIRM PASSWORD
    // =========================================================
 
    public void enterConfirmPassword(String password) {
 
        WebElement field =wait.until(ExpectedConditions.visibilityOfElementLocated(confirmPasswordField));
 
        field.clear();
 
        field.sendKeys(password);
    }
 
 
    // =========================================================
    // CLEAR CONFIRM PASSWORD
    // =========================================================
 
    public void clearConfirmPassword() {
 
        WebElement field =wait.until(ExpectedConditions.visibilityOfElementLocated(confirmPasswordField));
 
        field.clear();
    }
 
 
    // =========================================================
    // EMPLOYEE NAME - AUTOSUGGESTIVE DROPDOWN
    // =========================================================
 
    public void selectEmployeeAutocomplete(String searchText,String exactOptionText) {
 
        // Locate Employee Name field
        WebElement input = wait.until(ExpectedConditions.elementToBeClickable(employeeNameField));
 
 
        // Click input
        input.click();
 
 
        // Clear existing value
        input.clear();
 
 
        // Enter search text
        input.sendKeys(searchText);
 
 
        // Wait for autocomplete list
        wait.until(ExpectedConditions.visibilityOfElementLocated(employeeListBox));
 
 
        // Wait for actual results
        waitForAutocompleteResults();
 
 
        // Wait until at least one selectable option exists
        wait.until(d -> d.findElements(employeeOptions).size() > 0);
 
 
        // Exact employee option
        By exactOption =By.xpath("//*[@role='listbox']" +"//*[@role='option']" +"[normalize-space()=\"" +
                    exactOptionText +"\"]");
 
 
        WebElement target = null;
 
 
        // Try to find exact employee
        List<WebElement> exactMatches =
                driver.findElements(exactOption);
 
 
        if (!exactMatches.isEmpty()) {
 
            target = exactMatches.get(0);
 
        } else {
 
            // Fallback to first available option
            List<WebElement> fallback =
                    driver.findElements(
                            employeeOptions
                    );
 
            if (fallback.isEmpty()) {
 
                throw new TimeoutException(
                    "No selectable Employee Name found."
                );
            }
 
            target = fallback.get(0);
        }
 
 
        // Get employee text
        String selectedText;
 
        try {
 
            selectedText =
                    target.getText().trim();
 
        } catch (StaleElementReferenceException e) {
 
            // Re-find option if DOM refreshed
            List<WebElement> refreshed =
                    driver.findElements(
                            employeeOptions
                    );
 
            if (refreshed.isEmpty()) {
 
                throw new TimeoutException(
                    "Employee dropdown refreshed and no option was found."
                );
            }
 
            target = refreshed.get(0);
 
            selectedText =
                    target.getText().trim();
        }
 
 
        // Validate selected text
        if (selectedText.isEmpty()) {
 
            throw new TimeoutException(
                "Employee Name option is empty."
            );
        }
 
 
        // Click employee
        wait.until(ExpectedConditions.elementToBeClickable(target)).click();
 
 
        // Verify selected value
        wait.until(ExpectedConditions.attributeToBe(employeeNameField,"value",selectedText));
 
 
        System.out.println("Employee selected: "+ selectedText);
    }
 
 
    // =========================================================
    // WAIT FOR AUTOCOMPLETE RESULTS
    // =========================================================
 
    private void waitForAutocompleteResults() {
 
        By optionRows =By.xpath("//*[@role='listbox']//*[@role='option']");
 
 
        wait.until(d -> {
 
            List<WebElement> options =
                    d.findElements(optionRows);
 
 
            if (options.isEmpty()) {
 
                return false;
            }
 
 
            for (WebElement option : options) {
 
                try {
 
                    String text =
                            option.getText().trim();
 
 
                    if (!text.equalsIgnoreCase(
                            "Searching....")) {
 
                        return true;
                    }
 
                } catch (
                    StaleElementReferenceException e) {
 
                    return false;
                }
            }
 
 
            return false;
        });
 
 
        // Wait for loading message to disappear
        try {
 
            wait.until(ExpectedConditions.invisibilityOfElementWithText(optionRows,"Searching...."));
 
        } catch (TimeoutException e) {
 
            // Continue because actual result is already available
            System.out.println(
                "Loading message did not disappear, " +
                "but selectable employee result is available."
            );
        }
    }
 
 
    // =========================================================
    // GET SELECTED EMPLOYEE NAME
    // =========================================================
 
    public String getSelectedEmployeeName() {
 
        return wait.until(ExpectedConditions.visibilityOfElementLocated(employeeNameField)).getAttribute("value");
    }
 
 
    // =========================================================
    // SAVE BUTTON
    // =========================================================
 
    public void clickSaveButton() {wait.until(ExpectedConditions.elementToBeClickable(saveButton)).click();
    }
 
 
    // =========================================================
    // SUCCESS MESSAGE
    // =========================================================
 
    public String getSuccessMessage() {
 
        return wait.until(ExpectedConditions.visibilityOfElementLocated(successMessage)).getText();
    }
}