package pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
 
public class LoginPage {
 
    WebDriver driver;
 
    // Locators
    private By usernameField = By.name("username");
 
    private By passwordField = By.name("password");
 
    private By loginButton = By.xpath("//button[@type='submit']");
 
    private By requiredErrorMessage = By.cssSelector(".oxd-input-field-error-message");
 
    private By invalidLoginMessage = By.cssSelector(".oxd-alert-content-text");
 
 
    // Constructor
    public LoginPage(WebDriver driver) {
 
        this.driver = driver;
    }
 
 
    // Enter username
    public void enterUsername(String username) {
 
        driver.findElement(usernameField).sendKeys(username);
    }
 
 
    // Enter password
    public void enterPassword(String password) {
 
        driver.findElement(passwordField).sendKeys(password);
    }
 
 
    // Click Login
    public void clickLogin() {
 
        driver.findElement(loginButton).click();
    }
 
 
    // Get blank field error
    public String getRequiredErrorMessage() {
 
        return driver.findElement(requiredErrorMessage).getText();
    }
 
 
    // Get invalid login error
    public String getInvalidLoginMessage() {
 
        return driver.findElement(invalidLoginMessage).getText();
    }
 
 
    // Complete login
    public void login(String username, String password) {
 
        enterUsername(username);
        enterPassword(password);
        clickLogin();
    }
}