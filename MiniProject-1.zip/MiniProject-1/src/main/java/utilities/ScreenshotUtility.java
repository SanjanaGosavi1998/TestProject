package utilities;
 
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;
 
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
 
public class ScreenshotUtility {
 
   private static int screenshotNumber = 1;
 
   // Screenshot folder location
   private static final String SCREENSHOT_FOLDER =
          System.getProperty("user.dir") + "/Screenshots/";
 
   public static void takeScreenshot(
          WebDriver driver,
           String stepName) {
 
       // Create folder if it does not exist
       File folder = new File(SCREENSHOT_FOLDER);
 
       if (!folder.exists()) {
          folder.mkdirs();
       }
 
       // Current date and time
       String timestamp =
               new SimpleDateFormat(
                      "yyyyMMdd_HHmmss"
              ).format(new Date());
 
       // Replace spaces with underscore
       stepName = stepName.replaceAll(
              "[^a-zA-Z0-9-_]",
              "_"
       );
 
       // Screenshot filename
       String fileName =
              String.format(
                      "%02d_%s_%s.png",
                      screenshotNumber++,
                      stepName,
                      timestamp
               );
 
       String filePath =
              SCREENSHOT_FOLDER + fileName;
 
       // Take screenshot
      TakesScreenshot screenshot =
              (TakesScreenshot) driver;
 
       File source =
              screenshot.getScreenshotAs(
                      OutputType.FILE
               );
 
       File destination =
               new File(filePath);
 
       try {
 
          Files.copy(
                  source.toPath(),
                  destination.toPath(),
                  StandardCopyOption.REPLACE_EXISTING
           );
 
          System.out.println(
                  "Screenshot saved: "
                  + filePath
           );
 
       } catch (IOException e) {
 
          System.out.println(
                  "Failed to save screenshot: "
                  + e.getMessage()
           );
       }
   }
}
 