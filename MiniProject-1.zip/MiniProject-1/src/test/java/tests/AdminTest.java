package tests;
 


import org.testng.annotations.Test;

import base.BaseClass;
import pages.AdminPage;
import pages.LoginPage;
import utilities.ScreenshotUtility;
 

public class AdminTest extends BaseClass {
 

	@Test
	public void adminUserCreationTest() {
 
    	
    	
        AdminTest test = new AdminTest();
 
 
        try {
 
            // =====================================================
            // 1. LAUNCH APPLICATION
            // =====================================================
 
            System.out.println("===== Launching OrangeHRM =====");
 
            test.setUp();
 
            ScreenshotUtility.takeScreenshot(test.driver,"01_Application_Launched");
 
 
            // =====================================================
            // CREATE PAGE OBJECTS
            // =====================================================
 
            LoginPage loginPage =new LoginPage(test.driver);
 
            AdminPage adminPage = new AdminPage(test.driver);
 
 
            // =====================================================
            // 2. BLANK USERNAME AND PASSWORD
            // =====================================================
 
            System.out.println("===== Blank Login Validation =====");
 
            loginPage.clickLogin();
 
            String blankMessage =
                    loginPage.getRequiredErrorMessage();
 
            System.out.println( "Blank Field Error: " + blankMessage);
 
            ScreenshotUtility.takeScreenshot(test.driver,"02_Blank_Login_Validation");
 
 
            // =====================================================
            // 3. INVALID USERNAME AND PASSWORD
            // =====================================================
 
            System.out.println("===== Invalid Login Validation =====");
 
            loginPage.enterUsername("InAdmin");
 
            loginPage.enterPassword("Inadmin123");
 
            loginPage.clickLogin();
 
            String invalidLoginMessage =loginPage.getInvalidLoginMessage();
 
            System.out.println("Invalid Login Error: "+ invalidLoginMessage);
 
            ScreenshotUtility.takeScreenshot(test.driver,"03_Invalid_Login_Validation");
 
 
            // =====================================================
            // 4. VALID LOGIN
            // =====================================================
 
            System.out.println("===== Valid Login =====");
 
            loginPage.enterUsername("Admin");
 
            loginPage.enterPassword("admin123");
 
            loginPage.clickLogin();
 
            ScreenshotUtility.takeScreenshot(test.driver,"04_Valid_Login");
 
 
            // =====================================================
            // 5. CLICK ADMIN TAB
            // =====================================================
 
            System.out.println("===== Admin Page =====");
 
            adminPage.clickAdminTab();
 
            ScreenshotUtility.takeScreenshot(test.driver,"05_Admin_Tab");
 
 
            // =====================================================
            // 6. CLICK ADD BUTTON
            // =====================================================
 
            System.out.println("===== Add User =====");
 
            adminPage.clickAddButton();
 
            ScreenshotUtility.takeScreenshot(test.driver,"06_Add_User_Page");
 
 
            // =====================================================
            // 7. SELECT USER ROLE - ESS
            // =====================================================
 
            System.out.println("===== Selecting User Role =====");
 
            adminPage.selectUserRoleAsESS();
 
            ScreenshotUtility.takeScreenshot(test.driver,"07_User_Role_ESS_Selected");
 
 
            // =====================================================
            // 8. SELECT STATUS - ENABLED
            // =====================================================
 
            System.out.println("===== Selecting Status =====");
 
            adminPage.selectStatusAsEnabled();
 
            ScreenshotUtility.takeScreenshot(test.driver,"08_Status_Enabled_Selected");
 
 
            // =====================================================
            // 9. ENTER PASSWORD
            // =====================================================
 
            System.out.println("===== Enter Password =====");
 
            adminPage.enterPassword("India@2026");
 
            ScreenshotUtility.takeScreenshot(test.driver,"09_Password_Entered");
 
 
            // =====================================================
            // 10. ENTER USERNAME
            // =====================================================
 
            System.out.println("===== Enter Username =====");
 
            adminPage.enterUsername("username092");
 
            ScreenshotUtility.takeScreenshot(test.driver,"10_Username_Entered");
 
 
            // =====================================================
            // 11. ENTER WRONG CONFIRM PASSWORD
            // =====================================================
 
//            System.out.println(
//                    "===== Enter Incorrect Confirm Password ====="
//            );
// 
//            adminPage.enterConfirmPassword(
//                    "India"
//            );
// 
//            ScreenshotUtility.takeScreenshot(
//                    test.driver,
//                    "11_Incorrect_Confirm_Password"
//            );
 
 
            // =====================================================
            // 12. CLEAR WRONG CONFIRM PASSWORD
            // =====================================================
 
//            System.out.println(
//                    "===== Clear Incorrect Confirm Password ====="
//            );
// 
//            adminPage.clearConfirmPassword();
// 
//            ScreenshotUtility.takeScreenshot(
//                    test.driver,
//                    "12_Confirm_Password_Cleared"
//            );
 
 
            // =====================================================
            // 13. ENTER CORRECT CONFIRM PASSWORD
            // =====================================================
 
            System.out.println("===== Enter Correct Confirm Password =====");
 
            adminPage.enterConfirmPassword("India@2026");
 
            ScreenshotUtility.takeScreenshot(test.driver,"13_Correct_Confirm_Password");
 
 
            // =====================================================
            // 14. EMPLOYEE NAME AUTOSUGGESTIVE DROPDOWN
            // =====================================================
 
            System.out.println("===== Employee Name Search =====");
 
            adminPage.selectEmployeeAutocomplete("Auto","AutoTest QAQALab Selenium");
 
            ScreenshotUtility.takeScreenshot(test.driver,"14_Employee_Selected");
 
 
            // =====================================================
            // 15. VERIFY EMPLOYEE NAME
            // =====================================================
 
            String selectedEmployee =adminPage.getSelectedEmployeeName();
 
            System.out.println("Selected Employee: "+ selectedEmployee);
 
 
            if (
                selectedEmployee.equals("AutoTest QAQALab Selenium")
            ) {
 
                System.out.println("Employee selection verified successfully.");
 
            } else {
 
                System.out.println("Employee selection verification failed.");
            }
 
 
            ScreenshotUtility.takeScreenshot(test.driver,"15_Employee_Selection_Verified");
 
 
            // =====================================================
            // 16. CLICK SAVE
            // =====================================================
 
            System.out.println("===== Saving User Details =====");
 
            adminPage.clickSaveButton();
 
            ScreenshotUtility.takeScreenshot(test.driver,"16_User_Details_Saved");
 
 
            // =====================================================
            // 17. VERIFY SUCCESS MESSAGE
            // =====================================================
 
            try {
 
                String successMessage =adminPage.getSuccessMessage();
 
                System.out.println("Success Message: " + successMessage);
 
            } catch (Exception e) {
 
                System.out.println("User saved, but success toast " + "could not be captured.");
            }
 
 
            ScreenshotUtility.takeScreenshot(test.driver,"17_Flow_Completed");
 
 
            System.out.println("==========================================");
 
            System.out.println("ADMIN USER CREATION FLOW COMPLETED");
 
            System.out.println("==========================================");
 
 
        } catch (Exception e) {
 
 
            // =====================================================
            // FAILURE SCREENSHOT
            // =====================================================
 
            System.out.println("==========================================");
 
            System.out.println("TEST EXECUTION FAILED");
 
            System.out.println("==========================================");
 
 
            e.printStackTrace();
 
 
            if (test.driver != null) {
 
                ScreenshotUtility.takeScreenshot(test.driver,"FAILED_Test_Execution");
            }
 
 
        } finally {
 
 
            // =====================================================
            // CLOSE BROWSER
            // =====================================================
 
            test.tearDown();
        }
    }
}