package pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
 
public class BooksPage {
 
    WebDriver driver;
    WebDriverWait wait;
 
    public BooksPage(WebDriver driver, WebDriverWait wait) {
 
        this.driver = driver;
        this.wait = wait;
    }
 
    public void addBookToCart(String bookName) {
 
        By addToCartButton = By.xpath(
                "//div[contains(@class,'product-item')]" +
                "[.//a[contains(normalize-space(),'" + bookName + "')]]" +
                "//input[contains(@value,'Add to cart')]"
        );
 
        wait.until(
                ExpectedConditions.elementToBeClickable(addToCartButton))
                .click();
    }
 
    public boolean isBookAddedMessageDisplayed() {
 
        By message = By.cssSelector(".bar-notification.success");
 
        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(message))
                .isDisplayed();
    }
}