package pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
 
public class CheckOutPage {
 
    WebDriver driver;
    WebDriverWait wait;
 
 
    // ==========================================
    // BILLING ADDRESS
    // ==========================================
 
    By firstName =
            By.id("BillingNewAddress_FirstName");
 
    By lastName =
            By.id("BillingNewAddress_LastName");
 
    By email =
            By.id("BillingNewAddress_Email");
 
    By country =
            By.id("BillingNewAddress_CountryId");
 
    By city =
            By.id("BillingNewAddress_City");
 
    By address =
            By.id("BillingNewAddress_Address1");
 
    By zipCode =
            By.id("BillingNewAddress_ZipPostalCode");
 
    By phone =
            By.id("BillingNewAddress_PhoneNumber");
 
 
    // ==========================================
    // CONTINUE BUTTONS
    // ==========================================
 
    By billingContinue = By.cssSelector(
    	    "#billing-buttons-container .new-address-next-step-button"
    	);
 
    By shippingContinue =
            By.cssSelector(
                    "#shipping-buttons-container .new-address-next-step-button"
            );
 
    By shippingMethodContinue =
            By.cssSelector(
                    "#shipping-method-buttons-container .shipping-method-next-step-button"
            );
 
    By paymentMethodContinue =
            By.cssSelector(
                    "#payment-method-buttons-container .payment-method-next-step-button"
            );
 
    By paymentInfoContinue =
            By.cssSelector(
                    "#payment-info-buttons-container .payment-info-next-step-button"
            );
 
    By confirmOrderButton =
            By.cssSelector(
                    "#confirm-order-buttons-container .confirm-order-next-step-button"
            );
 
 
    // ==========================================
    // ORDER SUCCESS
    // ==========================================
 
    By orderSuccessMessage =
            By.cssSelector(".section.order-completed .title");
 
 
    public CheckOutPage(WebDriver driver, WebDriverWait wait) {
 
        this.driver = driver;
        this.wait = wait;
    }
 
 
    // ==========================================
    // REUSABLE TEXT FIELD METHOD
    // ==========================================
 
    private void enterValue(By locator, String value) {
 
        WebElement element =
                wait.until(
                        ExpectedConditions.visibilityOfElementLocated(locator)
                );
 
        element.clear();
 
        element.sendKeys(value);
    }
 
 
    // ==========================================
    // BILLING ADDRESS
    // ==========================================
 
    public void fillBillingAddress(
            String firstNameValue,
            String lastNameValue,
            String emailValue,
            String countryValue,
            String cityValue,
            String addressValue,
            String zipValue,
            String phoneValue) {
 
        enterValue(firstName, firstNameValue);
 
        enterValue(lastName, lastNameValue);
 
        enterValue(email, emailValue);
 
 
        // Country dropdown
 
        Select countryDropdown =
                new Select(
                        wait.until(
                                ExpectedConditions.visibilityOfElementLocated(country)
                        )
                );
 
        countryDropdown.selectByVisibleText(countryValue);
 
 
        enterValue(city, cityValue);
 
        enterValue(address, addressValue);
 
        enterValue(zipCode, zipValue);
 
        enterValue(phone, phoneValue);
    }
 
 
    // ==========================================
    // BILLING CONTINUE
    // ==========================================
 
    public void continueBilling() {
 
    	WebElement button = wait.until(
    	        ExpectedConditions.elementToBeClickable(billingContinue)
    	    );
 
    	    ((JavascriptExecutor) driver).executeScript(
    	        "arguments[0].scrollIntoView({block:'center'});",
    	        button
    	    );
 
    	    button.click();
    	    
    	 // Wait until Shipping Address section becomes active/visible
    	    wait.until(ExpectedConditions.visibilityOfElementLocated(
    	        By.cssSelector("#checkout-step-shipping")
    	    ));
    }
 
 
    // ==========================================
    // SHIPPING
    // ==========================================
 
    public void continueShipping() {
 
        WebElement button =
                wait.until(
                        ExpectedConditions.elementToBeClickable(
                                shippingContinue
                        )
                );
 
        button.click();
    }
 
 
    // ==========================================
    // SHIPPING METHOD
    // ==========================================
 
    public void continueShippingMethod() {
 
        WebElement button =
                wait.until(
                        ExpectedConditions.elementToBeClickable(
                                shippingMethodContinue
                        )
                );
 
        button.click();
    }
 
 
    // ==========================================
    // PAYMENT METHOD
    // ==========================================
 
    public void continuePaymentMethod() {
 
        WebElement button =
                wait.until(
                        ExpectedConditions.elementToBeClickable(
                                paymentMethodContinue
                        )
                );
 
        button.click();
    }
 
 
    // ==========================================
    // PAYMENT INFORMATION
    // ==========================================
 
    public void continuePaymentInformation() {
 
        WebElement button =
                wait.until(
                        ExpectedConditions.elementToBeClickable(
                                paymentInfoContinue
                        )
                );
 
        button.click();
    }
 
 
    // ==========================================
    // CONFIRM ORDER
    // ==========================================
 
    public void confirmOrder() {
 
        WebElement button =
                wait.until(
                        ExpectedConditions.elementToBeClickable(
                                confirmOrderButton
                        )
                );
 
        button.click();
    }
 
 
    // ==========================================
    // VERIFY ORDER
    // ==========================================
 
    public boolean isOrderSuccessful() {
 
        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        orderSuccessMessage
                )
        ).isDisplayed();
    }
}