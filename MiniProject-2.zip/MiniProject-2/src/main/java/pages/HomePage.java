package pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
 
public class HomePage {
 
    WebDriver driver;
    WebDriverWait wait;
 
    By booksLink = By.cssSelector("a[href='/books']");
 
    By shoppingCart = By.cssSelector("a[href='/cart']");
 
    public HomePage(WebDriver driver, WebDriverWait wait) {
 
        this.driver = driver;
        this.wait = wait;
    }
 
    public void clickBooks() {
 
        wait.until(ExpectedConditions.elementToBeClickable(booksLink))
                .click();
    }
 
    public void openShoppingCart() {
 
        wait.until(ExpectedConditions.elementToBeClickable(shoppingCart))
                .click();
    }
}
 