package pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
 
public class LoginPage {
 
    WebDriver driver;
    WebDriverWait wait;
 
    // Login link on Home Page
    By loginLink = By.cssSelector("a[href='/login']");
 
    // Login Page elements
    By email = By.id("Email");
 
    By password = By.id("Password");
 
    By loginButton = By.cssSelector("input[value='Log in']");
 
    By logoutLink = By.cssSelector("a[href='/logout']");
 
 
    public LoginPage(WebDriver driver, WebDriverWait wait) {
 
        this.driver = driver;
        this.wait = wait;
    }
 
 
    // Click Login link from Home Page
    public void clickLogin() {
 
        wait.until(
                ExpectedConditions.elementToBeClickable(loginLink)
        ).click();
    }
 
 
    public void enterEmail(String emailValue) {
 
        wait.until(
                ExpectedConditions.visibilityOfElementLocated(email)
        ).sendKeys(emailValue);
    }
 
 
    public void enterPassword(String passwordValue) {
 
        wait.until(
                ExpectedConditions.visibilityOfElementLocated(password)
        ).sendKeys(passwordValue);
    }
 
 
    public void clickLoginButton() {
 
        wait.until(
                ExpectedConditions.elementToBeClickable(loginButton)
        ).click();
    }
 
 
    public void login(String emailValue, String passwordValue) {
 
        // First open Login Page
        clickLogin();
 
        // Enter credentials
        enterEmail(emailValue);
 
        enterPassword(passwordValue);
 
        // Click Login
        clickLoginButton();
    }
 
 
    public boolean isLoggedIn() {
 
        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(logoutLink)
        ).isDisplayed();
    }
}