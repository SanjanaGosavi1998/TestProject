package pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
 
public class ShoppingCartPage {
 
    WebDriver driver;
    WebDriverWait wait;
 
    By termsCheckbox = By.id("termsofservice");
 
    By checkoutButton = By.id("checkout");
 
    public ShoppingCartPage(WebDriver driver, WebDriverWait wait) {
 
        this.driver = driver;
        this.wait = wait;
    }
 
    public boolean isProductPresent(String productName) {
 
        By product = By.xpath(
                "//a[contains(@class,'product-name')" +
                " and normalize-space()='" + productName + "']"
        );
 
        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(product))
                .isDisplayed();
    }
 
    public void proceedToCheckout() {
 
        wait.until(
                ExpectedConditions.elementToBeClickable(termsCheckbox))
                .click();
 
        wait.until(
                ExpectedConditions.elementToBeClickable(checkoutButton))
                .click();
    }
}