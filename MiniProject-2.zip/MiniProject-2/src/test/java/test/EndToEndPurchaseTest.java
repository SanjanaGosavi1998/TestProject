package test;
 
import org.testng.Assert;
import org.testng.annotations.Test;
 
import base.BaseClass;
import pages.BooksPage;
import pages.CheckOutPage;
import pages.HomePage;
import pages.LoginPage;
import pages.ShoppingCartPage;
 
public class EndToEndPurchaseTest extends BaseClass {
 
    @Test
    public void completeBookPurchase() {
 
        // ==========================================
        // TEST DATA
        // ==========================================
 
        String email = "sanjagosavi@gmail.com";
 
        String password = "Sanjagosavi@2026";
 
        String bookName = "Computing and Internet";
 
        String firstName = "Sanjana";
 
        String lastName = "Gosavi";
 
        String country = "India";
 
        String city = "Mumbai";
 
        String address = "Test Address";
 
        String zipCode = "400001";
 
        String phone = "9876543210";
 
 
        // ==========================================
        // 1. LOGIN
        // ==========================================
 
        LoginPage loginPage =
                new LoginPage(driver, wait);
 
        loginPage.login(email, password);
 
        Assert.assertTrue(
                loginPage.isLoggedIn(),
                "Login was unsuccessful"
        );
 
 
        // ==========================================
        // 2. GO TO BOOKS
        // ==========================================
 
        HomePage homePage =
                new HomePage(driver, wait);
 
        homePage.clickBooks();
 
 
        // ==========================================
        // 3. ADD BOOK TO CART
        // ==========================================
 
        BooksPage booksPage =
                new BooksPage(driver, wait);
 
        booksPage.addBookToCart(bookName);
 
        Assert.assertTrue(
                booksPage.isBookAddedMessageDisplayed(),
                "Book was not added to cart"
        );
 
 
        // ==========================================
        // 4. OPEN SHOPPING CART
        // ==========================================
 
        homePage.openShoppingCart();
 
        ShoppingCartPage cartPage =
                new ShoppingCartPage(driver, wait);
 
        Assert.assertTrue(
                cartPage.isProductPresent(bookName),
                "Book is not present in shopping cart"
        );
 
 
        // ==========================================
        // 5. CHECKOUT
        // ==========================================
 
        cartPage.proceedToCheckout();
 
 
        // ==========================================
        // 6. BILLING ADDRESS
        // ==========================================
 
        CheckOutPage checkoutPage =
                new CheckOutPage(driver, wait);
 
//        checkoutPage.fillBillingAddress(
//                firstName,
//                lastName,
//                email,
//                country,
//                city,
//                address,
//                zipCode,
//                phone
//        );
 
 
        // ==========================================
        // 7. SHIPPING ADDRESS
        // ==========================================
 
        checkoutPage.continueBilling();
 
 
        checkoutPage.continueShipping();
 
 
        // ==========================================
        // 8. SHIPPING METHOD
        // ==========================================
 
        checkoutPage.continueShippingMethod();
 
 
        // ==========================================
        // 9. PAYMENT METHOD
        // ==========================================
 
        checkoutPage.continuePaymentMethod();
 
 
        // ==========================================
        // 10. PAYMENT INFORMATION
        // ==========================================
 
        checkoutPage.continuePaymentInformation();
 
 
        // ==========================================
        // 11. CONFIRM ORDER
        // ==========================================
 
        checkoutPage.confirmOrder();
 
 
        // ==========================================
        // 12. VERIFY ORDER
        // ==========================================
 
        Assert.assertTrue(
                checkoutPage.isOrderSuccessful(),
                "Order was not placed successfully"
        );
 
        System.out.println(
                "Order placed successfully!"
        );
    }
}