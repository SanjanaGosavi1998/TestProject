package Test;

import org.testng.annotations.Test;

import Base.BaseTest;
import pages.Registration;

public class RegistrationTest extends BaseTest {
	
	@Test
	public void registerUser() {
		Registration register=new Registration(driver);
		
		register.enterusername("Sanjana", "Gosavi","sanja@gmail.com","8879784887","Small@1234","Small@1234");
	}
	

}
