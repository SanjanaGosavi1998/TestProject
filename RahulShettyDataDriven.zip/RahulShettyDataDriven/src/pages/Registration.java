package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Registration {
	
	WebDriver driver;
	public Registration(WebDriver driver) {
		this.driver=driver;
	}
	
	
	By firstName= By.id("firstName");
	By lastName= By.xpath("//input[@type='lastName']");
	By email= By.id("userEmail");
	By mobileNumber= By.id("userMobile");
	By occupation= By.xpath("//select[@class='custom-select.ng-untouched.ng-pristine.ng-valid']");
	By genderFemale= By.xpath("//label/input[@value='Female']");
	By genderMale= By.xpath("//label/input[@value='Male']");
	By password= By.id("userPassword");
	By confirmPassword= By.id("confirmPassword");
	By registerButton= By.xpath("//a[@class='btn1']");


public void enterusername(String fn, String ln, String em,String mn ,String pss, String cPss) {
	driver.findElement(firstName).sendKeys(fn);
	driver.findElement(lastName).sendKeys(ln);
	driver.findElement(email).sendKeys(em);
	driver.findElement(mobileNumber).sendKeys(mn);
	driver.findElement(occupation).click();
	driver.findElement(genderFemale).click();
	driver.findElement(password).sendKeys(pss);
	driver.findElement(confirmPassword).sendKeys(cPss);
	driver.findElement(registerButton).click();
}
}
