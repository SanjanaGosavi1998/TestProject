package BasicPrograms;

public class Factorial {

	public static void main(String[] args) {
		int fact=1;
		for(int i=5; i>=1; i--) 
		{
			int fact1=(fact*i);
			System.out.println(fact1);
		}

	}

}
