package BasicPrograms;

public class Practice {

	public static void main(String[] args) {
		
		//sum of 1-20 numbers
		int sum=0;
		for(int i=1;i<=20; i++)
		{
			sum=(sum+i);
			System.out.println(sum);
		}

	}

}
