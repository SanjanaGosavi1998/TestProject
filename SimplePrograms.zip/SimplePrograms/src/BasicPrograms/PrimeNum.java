package BasicPrograms;

public class PrimeNum {

	public static void main(String[] args) {
		
		//If a number is divisible by only 1 and itself, it is prime.
		
		int num=7;
		int count=0;
		
		for(int i=1;i<=num;i++) 
		{
			if(num%i==0)
			{
				count++;
			}
		}
		
		if(count==2)
		{
			System.out.println("Prime Number");
		}
		else {
			System.out.println("Not a Prime Number");
		}

	}

}

