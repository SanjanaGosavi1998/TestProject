package BasicPrograms;

public class SumOfOddNo {
	
	public static void main(String args[])
	{
		int sum=0;
		for(int i=1; i<=20; i++)
		{
			if(i%2 != 0)
			{
				int sum1=(sum+i);
			System.out.println(sum1);
			}
		}
	}
}
