package BasicPrograms;

public class SumofEvenNo {

	public static void main(String[] args) {
		
		//int sum=0;
		
		for(int i=1; i<=20; i++) 
		{
			if(i%2==0) 
			{
				//int sum1=(sum+i);
				System.out.println(i);
			}
		}
		
		//or
		int a=6;
		if(a%2==0)
		{
			System.out.println("a is even number");
		}

	}

}
