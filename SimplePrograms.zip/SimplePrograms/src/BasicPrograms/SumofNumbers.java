package BasicPrograms;

public class SumofNumbers {

	public static void main(String[] args) {
		
		int sum=0;
		for(int i=1; i<=20; i++)
		{
		sum += i;	
		}
		System.out.println("The sum of numbers:" + sum);
	}
}
