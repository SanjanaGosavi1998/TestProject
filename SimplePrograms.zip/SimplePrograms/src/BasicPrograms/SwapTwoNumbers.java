package BasicPrograms;

public class SwapTwoNumbers {

	public static void main(String[] args) {
		
		int a=10;
		int b=20;
		
		System.out.println("Before: a="+a+" , b="+b);
		
		//By using Arithmetic operation
		a=a+b;      //a=30
		b=a-b;      //b=30-20=10
		a=a-b;      //a=30-10=20
		
		//Using XOR
		a=a^b;
		b=a^b;
		a=a^b;
		
		System.out.println("After: a="+a+" , b="+b);

	}

}
