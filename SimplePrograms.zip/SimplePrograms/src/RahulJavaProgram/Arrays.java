package RahulJavaProgram;

import java.util.ArrayList;

public class Arrays {

	public static void main(String[] args) {
		
		//Arrays
		int a[]= {1,2,3,4,5,6,7,8};
		System.out.println(a[3]);
		
		//or
		
		int b[]=new int[3];
		b[0]=1;
		b[1]=2;
		b[2]=3;
		System.out.println(b[1]);

		for(int i=0; i<a.length; i++)
		{
			System.out.println(a[i]);
		}
		
		String name[]= {"Java", "Selenium","Course"};
		for(int i=0; i<name.length; i++)
		{
			System.out.println(name[i]);
			System.out.println(name[1]);
		}
		
		//If else conditions - Multiply by 2 program-
		int k[]= {1,2,3,4,5,6,7,8,9,10,122};
		System.out.println(k.length);
		
		for(int i=0; i<k.length; i++)
		{
			if(k[i]%2==0)
			{
				System.out.println(k[i]);
			}
			else
			{
				System.out.println(k[i] + " "+"This is not multiply of 2");
			}
			
		}
		
		//Check array and grab the first value which is multiple by 2
		for(int i=0; i<k.length; i++)
		{
			if(k[i]%2==0)
			{
				System.out.println(k[i]+ " " + "value which is multiply by 2");
				break;
			}
		}
		
		//MultiDimension Array
		//a[row][column]
		
		int t[][] = new int [2][3];
		
		t[0][0]=2;
		t[0][1]=4;
		t[0][2]=5;
		t[1][0]=3;
		t[1][1]=4;
		t[1][2]=7;
		System.out.println(t[1][1]);
		
		//or
		int f[][]= {{2,4,5}, {3,4,7}};
		
		for(int i=0; i<2; i++)
		{
			for(int j=0; j<3; j++)
			{
				System.out.println(f[i][j]);
			}
		}
		
		//ArrayList
		
		ArrayList<String> x=new ArrayList<String>();
		x.add("Sanjana");
		x.add("Gosavi");
		x.add("Sanja");
		x.add("Shraddha");
		System.out.println(x);
		System.out.println(x.get(1));
		System.out.println(x.contains("Sanju"));
		System.out.println(x.indexOf("Sanjana"));
		System.out.println(x.isEmpty());
		System.out.println(x.size());
		for(int i=0; i<x.size(); i++)
		{
			System.out.println(x.get(i));
		}
		
		//Strings --
		String s="Welcome";
		String s1="Welcome"; //Won't create new object 
		
		String s2= new String("Welcome");
		String s3= new String("Welcome"); //create new object in memory space
		
		String s4="Rahul Shetty academy";
		String[] SplittedString = s4.split(" ");
		System.out.println(SplittedString[0]);
		System.out.println(SplittedString[1]);
		System.out.println(SplittedString[2]);
		
		String[] SplittedString1=s4.split("Shetty");
		System.out.println(SplittedString1[0]);
		System.out.println(SplittedString1[1]);
		System.out.println(SplittedString1[1].trim()); //Remove Space which present before academy
		
		//Print character of String
		for(int i=0; i<s4.length(); i++)
		{
			System.out.println(s4.charAt(i));
		}
		
		//Reverse
		for(int i=s4.length()-1; i>=0; i--)
		{
			System.out.println(s4.charAt(i));
		}
		
		//Non-Static method
		Arrays n=new Arrays();
		String name1=n.getData();
		System.out.println(name1);
	}
	
	public String getData()
	{
		System.out.println("Hello World");
		return "Rahul Shetty";
	}

}
