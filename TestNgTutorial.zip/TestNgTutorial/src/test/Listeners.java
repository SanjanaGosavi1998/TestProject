package test;

import org.testng.ITestListener;

//ITestListener interface which implements testng listerners

public class Listeners implements ITestListener {

}
