package test;

import org.testng.annotations.AfterMethod;

public class PS {

	public void dothis() {
		System.out.println("I am here");
	}
	
	@AfterMethod
	public void AfterRun() {
		System.out.println("Run me Last");
	}
}
