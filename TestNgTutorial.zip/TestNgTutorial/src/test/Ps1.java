package test;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Ps1 extends PS{
	
	@Test
	public void testRun() {
		dothis();
	}
	
	@BeforeMethod
	public void afterRun() {
		System.out.println("Run me first");
	}

}
