package test;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class day1 {
	
	@AfterTest
	public void lastexecution() {
		System.out.println("I will execute last");
	}

	@Test
	public void demo() {
		System.out.println("Hello");
	}

	@AfterSuite
	public void AtSuite() {
		System.out.println("I am the no.1 from last");
	}
	
	
	@Parameters({ "URL" })
	@Test
	public void secondTest(String urlname) {
	System.out.println("Byee");
	System.out.println(urlname);
}
}