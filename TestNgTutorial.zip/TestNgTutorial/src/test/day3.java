package test;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class day3 {

	@BeforeClass
	public void beclass() {
		System.out.println("Before executing any method in the class");
	}
	
	@Parameters({"URL"})
	@Test
	public void WebLoginCarLoan(String urlname) {
		System.out.println("WebLoginCar");
		System.out.println(urlname);
	}
	
	@Test(groups= {"smoke"})
	public void MobileLoginCarLoan() {
		System.out.println("MobileLoginCar");
	}
	
	@BeforeSuite
	public void Bfsuit() {
		System.out.println("I am no.1");
	}
	
	@Test(enabled=false)
	public void MobileSignInCarLoan() {
		System.out.println("MobileSignInCar");
	}
	
	@Test(dataProvider="getData")
	public void MobilesSignOutCarLoan(String username, String password) {
		System.out.println("MobilesSignOutCar");
		System.out.println(username);
		System.out.println(password);
	}
	
	
	@Test(timeOut=4000)
	public void MobileSignOutCarLoan() {
		System.out.println("MobileSignOutCar");
	}
	
	@AfterClass
	public void afclass() {
		System.out.println("After executing all method in the class");
	}
	
	@Test(dependsOnMethods= {"WebLoginCarLoan"})
	public void APILoginCarLoan() {
		System.out.println("APILoginCar");
	}
	
	@DataProvider
	public Object[][] getData() {
		//1st=username, password which are valid
		//2nd =username , password which are Invalid
		//3rd = username ,password which are default 
		
		Object[][] data=new Object[3][2];
		
		data[0][0]="FirstSetUsername";
		data[0][1]="Firstpassword";
		
		data[1][0]="SecondSetUsername";
		data[1][1]="Secondpassword";
		
		data[2][0]="ThirdSetUsername";
		data[2][1]="Thirdpassword";
		return data;
	}
	

}

