package test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class day4 {
	
	@Parameters({"URL", "Username"})
	@Test
	public void WebLoginHomeLoan(String urlname, String name) {
		System.out.println("WebLoginHome");
		System.out.println(urlname);
		System.out.println(name);
	}
	
	@BeforeMethod
	public void beforeevery() {
		System.out.println("I will execute before every class in day4");
	}
	
	@Test(groups= {"smoke"})
	public void MobileLoginHomeLoan() {
		System.out.println("MobileLoginHome");
	}
	
	@AfterMethod
	public void afterevery() {
		System.out.println("I will execute after every class in day4");
	}
	
	@Test
	public void APILoginHomeLoan() {
		System.out.println("APILoginHome");
	}

}
